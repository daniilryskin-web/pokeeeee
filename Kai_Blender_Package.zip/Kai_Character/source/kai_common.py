import bpy, math
from mathutils import Vector

def mesh_object(name, verts, faces, material):
    mesh=bpy.data.meshes.new(name+'_Mesh')
    mesh.from_pydata(verts,[],faces); mesh.update()
    obj=bpy.data.objects.new(name,mesh); bpy.context.collection.objects.link(obj)
    if material: mesh.materials.append(material)
    for p in mesh.polygons:p.use_smooth=True
    return obj

def uv_smart(obj):
    bpy.ops.object.select_all(action='DESELECT'); obj.select_set(True); bpy.context.view_layer.objects.active=obj
    bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.uv.smart_project(angle_limit=math.radians(70),island_margin=.015)
    bpy.ops.object.mode_set(mode='OBJECT')

def tube(name,points,radii,material,sides=12,aspect=1.0,caps=True):
    points=[Vector(p) for p in points]; verts=[]; faces=[]
    for i,p in enumerate(points):
        tangent=(points[min(i+1,len(points)-1)]-points[max(0,i-1)]).normalized()
        ref=Vector((0,0,1)) if abs(tangent.z)<.9 else Vector((0,1,0))
        u=tangent.cross(ref).normalized(); v=tangent.cross(u).normalized()
        radius=radii[i] if isinstance(radii,(list,tuple)) else radii
        for j in range(sides):
            a=2*math.pi*j/sides; verts.append(tuple(p+radius*(u*math.cos(a)+v*math.sin(a)*aspect)))
    for i in range(len(points)-1):
        for j in range(sides):
            a=i*sides+j;b=i*sides+(j+1)%sides; faces.append((a,b,b+sides,a+sides))
    if caps:faces.extend([tuple(range(sides-1,-1,-1)),tuple((len(points)-1)*sides+j for j in range(sides))])
    ob=mesh_object(name,verts,faces,material)
    uv=ob.data.uv_layers.new(name='UVMap')
    for poly in ob.data.polygons:
        for li in poly.loop_indices:
            vi=ob.data.loops[li].vertex_index; uv.data[li].uv=((vi%sides)/sides,(vi//sides)/(len(points)-1))
    return ob

def ribbon(name, centers, widths, material, width_axis=(1,0,0), thickness=.001):
    verts=[];faces=[];axis=Vector(width_axis)
    for i,p in enumerate(centers):
        w=widths[i] if isinstance(widths,(tuple,list)) else widths
        p=Vector(p);verts.extend([tuple(p-axis*w/2),tuple(p+axis*w/2)])
    for i in range(len(centers)-1):faces.append((2*i,2*i+1,2*i+3,2*i+2))
    ob=mesh_object(name,verts,faces,material)
    if thickness:
        mod=ob.modifiers.new('Tailored thickness','SOLIDIFY');mod.thickness=thickness
    uv=ob.data.uv_layers.new(name='UVMap')
    for poly in ob.data.polygons:
        for li in poly.loop_indices:
            vi=ob.data.loops[li].vertex_index;uv.data[li].uv=(vi%2,(vi//2)/max(1,len(centers)-1))
    return ob

def bezier_points(p0,p1,p2,p3,count=20):
    ps=list(map(Vector,[p0,p1,p2,p3]));return [tuple((1-t)**3*ps[0]+3*t*(1-t)**2*ps[1]+3*t*t*(1-t)*ps[2]+t**3*ps[3]) for t in [i/(count-1) for i in range(count)]]

def apply_modifiers(obj):
    bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj
    for mod in list(obj.modifiers):bpy.ops.object.modifier_apply(modifier=mod.name)
