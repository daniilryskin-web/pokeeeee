import bpy,math
from mathutils import Vector
from kai_common import mesh_object,tube,ribbon
from kai_rig import hand_layout

def build(ctx):
 mats=ctx['mats'];reg=ctx['register'];out=[]
 def add(obj,weights=None,rigid=None):reg(obj,weights=weights,rigid=rigid);out.append(obj);return obj
 def rings(name,centers,widths,depths,w,mat,boneweights,sides=16):
  verts=[];faces=[];weights={}
  for i,c in enumerate(centers):
   for j in range(sides):
    a=2*math.pi*j/sides;index=len(verts)
    verts.append(tuple(Vector(c)+w*widths[i]*math.cos(a)+Vector((0,depths[i]*math.sin(a),0))))
    for b,v in boneweights[i].items():weights.setdefault(b,{})[index]=v
  for i in range(len(centers)-1):
   for j in range(sides):
    a=i*sides+j;b=i*sides+(j+1)%sides;faces.append((a,b,b+sides,a+sides))
  faces+=[tuple(range(sides-1,-1,-1)),tuple((len(centers)-1)*sides+j for j in range(sides))]
  ob=mesh_object(name,verts,faces,mat)
  uv=ob.data.uv_layers.new(name='UVMap')
  for poly in ob.data.polygons:
   for li in poly.loop_indices:
    vi=ob.data.loops[li].vertex_index;j=vi%sides;i=vi//sides
    u=j/sides
    if poly.index<(len(centers)-1)*sides and poly.index%sides==sides-1 and j==0:u=1
    uv.data[li].uv=(u,i/(len(centers)-1))
  return add(ob,weights)
 for sign,s in [(1,'l'),(-1,'r')]:
  origin,d,w,layout=hand_layout(sign)
  armstart=Vector((sign*.315,0,1.025));centers=[]
  for t in [0,.12,.25,.4,.55,.70,.83,.94,1.02]:centers.append(armstart.lerp(origin,t))
  rings('Kai_Forearm_'+s,centers,[.031,.032,.030,.028,.025,.022,.019,.017,.017],[.027,.028,.026,.024,.021,.019,.016,.015,.015],w,mats['skin'],[{'lowerarm_'+s:1} for _ in centers],20)
  ts=[-.006,0,.012,.025,.037,.045,.051]
  rings('Kai_Palm_'+s,[origin+d*t for t in ts],[.017,.019,.024,.027,.027,.025,.022],[.015,.016,.018,.019,.018,.016,.012],w,mats['skin'],[{'hand_'+s:1} for _ in ts],24)
  # Fitted fingerless glove with a shaped palm, wrist belt and fabric seam edges.
  ts=[-.005,.002,.012,.024,.035,.043]
  rings('Kai_Glove_'+s,[origin+d*t for t in ts],[.018,.020,.025,.028,.028,.026],[.016,.017,.019,.020,.019,.017],w,mats['black'],[{'hand_'+s:1} for _ in ts],24)
  cuffcenter=origin-d*.006
  rings('Kai_WristBand_'+s,[cuffcenter-d*.008,cuffcenter-d*.006,cuffcenter+d*.006,cuffcenter+d*.008],[.020]*4,[.0175]*4,w,mats['navy_light'],[{'hand_'+s:1}]*4,24)
  tab=ribbon('Kai_WristCyan_'+s,[tuple(cuffcenter+w*t+Vector((0,-.017,0))) for t in [-.017,0,.017]],.009,mats['cyan'],width_axis=tuple(d),thickness=.0015);add(tab,rigid='hand_'+s)
  for name,ps in layout.items():
   centers=[];widths=[];depths=[];bw=[]
   for seg in range(3):
    for j in range(4):
     t=j/4;p=ps[seg].lerp(ps[seg+1],t);globalt=(seg+t)/3
     centers.append(p);r=(.0069 if name=='thumb' else .0062)*(1-.27*globalt)
     if name=='pinky':r*=.82
     widths.append(r);depths.append(r*.86)
     key=f'{name}_{seg+1:02d}_{s}'
     wd={key:1}
     if seg>0 and t<.25:wd={f'{name}_{seg:02d}_{s}':.25,key:.75}
     bw.append(wd)
   centers+=[ps[-1],ps[-1]+(ps[-1]-ps[-2]).normalized()*.0015]
   widths+=[widths[-1]*.68,.0009];depths+=[depths[-1]*.68,.0009];bw+=[{f'{name}_03_{s}':1}]*2
   rings(f'Kai_{name.title()}_{s}',centers,widths,depths,w,mats['skin'],bw,12)
   # Open-tip fabric sleeve on first finger phalanx.
   centers_g=[ps[0]+(ps[1]-ps[0])*t for t in [-.10,.15,.45,.7]]
   radius=(.0073 if name=='thumb' else .0067)*(.82 if name=='pinky' else 1)
   rings(f'Kai_Glove_{name}_{s}',centers_g,[radius]*4,[radius*.9]*4,w,mats['black'],[{f'{name}_01_{s}':1}]*4,12)
   # Slightly raised nail on dorsal side (-Y), carefully inset near fingertip.
   end=ps[-1];direction=(ps[-1]-ps[-2]).normalized();nc=end-direction*.006+Vector((0,-depths[-3]-.00035,0))
   verts=[]
   for a in range(12):
    ang=2*math.pi*a/12;verts.append(tuple(nc+w*.0032*math.cos(ang)+direction*.0044*math.sin(ang)))
   nail=mesh_object(f'Kai_Nail_{name}_{s}',verts,[tuple(range(12))],mats['skin']);add(nail,rigid=f'{name}_03_{s}')
  # Back-of-hand stitched inset follows palm, no chunky armor plate.
  c=origin+d*.028+Vector((0,-.0204,0))
  perimeter=[c+w*.019+d*.010,c+w*.014+d*.018,c-w*.014+d*.018,c-w*.019+d*.010,c-w*.018-d*.008,c+w*.018-d*.008,c+w*.019+d*.010]
  add(tube('Kai_GloveStitch_'+s,perimeter,.00055,mats['stitch'],sides=5),rigid='hand_'+s)
 return out
