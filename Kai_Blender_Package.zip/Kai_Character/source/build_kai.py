"""Run: blender -b -t 4 --python source/build_kai.py -- [--skip-render]
Creates an explicitly WIP procedural character asset, textures and FBX exports.
"""
import bpy,sys,os,math,json,time,collections
from mathutils import Vector
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));sys.path.insert(0,os.path.join(ROOT,'source'))
from kai_common import uv_smart,apply_modifiers
from kai_materials import build_materials
from kai_rig import build_rig
import kai_hands,kai_head,kai_jacket,kai_lower,kai_animation

def log(s):print('KAI:',s,flush=True)
def world_bbox(objects):
 points=[o.matrix_world@Vector(c) for o in objects for c in o.bound_box]
 return [[min(p[i] for p in points),max(p[i] for p in points)] for i in range(3)]

def fallback_weights(obj):
 weights={}
 for v in obj.data.vertices:
  x,y,z=v.co;ax=abs(x);s='l' if x>=0 else 'r'
  def blend(a,b,t):
   t=min(1,max(0,t));return {a:1-t,b:t}
  if z>1.29 and ax<.23:ws={'head':1}
  elif z>1.235 and ax<.10:ws=blend('neck_01','head',(z-1.26)/.05)
  elif ax>.175 and z>.865:
   if ax>.40:ws={'hand_'+s:1}
   else:ws=blend('upperarm_'+s,'lowerarm_'+s,(ax-.28)/.08)
  elif z>.85:
   if z<.95:ws=blend('pelvis','spine_01',(z-.87)/.08)
   elif z<1.08:ws=blend('spine_01','spine_02',(z-.96)/.12)
   else:ws=blend('spine_02','spine_03',(z-1.08)/.13)
  elif z>.71:ws=blend('thigh_'+s,'pelvis',(z-.73)/.13)
  elif z>.37:ws=blend('calf_'+s,'thigh_'+s,(z-.39)/.14)
  elif z>.15:ws={'calf_'+s:1}
  else:ws={'foot_'+s:1}
  for b,w in ws.items():
   if w>1e-6:weights.setdefault(b,{})[v.index]=w
 return weights

def assign_groups(obj,weights):
 for bone,values in weights.items():
  group=obj.vertex_groups.get(bone) or obj.vertex_groups.new(name=bone)
  buckets=collections.defaultdict(list)
  for idx,w in values.items():
   if w>1e-6:buckets[round(w,5)].append(idx)
  for w,ids in buckets.items():group.add(ids,w,'REPLACE')

def point_camera(camera,target):camera.rotation_euler=(Vector(target)-camera.location).to_track_quat('-Z','Y').to_euler()
def setup_stage():
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False
 scene.cycles.max_bounces=6;scene.cycles.diffuse_bounces=3;scene.cycles.glossy_bounces=3
 scene.render.resolution_x=1000;scene.render.resolution_y=1200;scene.render.resolution_percentage=100
 scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
 scene.world.color=(.12,.12,.12)
 scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.32,.38,.50,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.35
 scene.view_settings.view_transform='AgX'
 stage=bpy.data.collections.new('STUDIO__not_exported');scene.collection.children.link(stage)
 def move(obj):
  for coll in list(obj.users_collection):coll.objects.unlink(obj)
  stage.objects.link(obj)
 bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.007));floor=bpy.context.object;floor.name='Studio_Floor';move(floor)
 m=bpy.data.materials.new('Studio_Matte');m.diffuse_color=(.17,.21,.28,1);m.use_nodes=True;m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value=(.17,.21,.28,1);m.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value=.85;floor.data.materials.append(m)
 for name,loc,power,size,color in [('Key',(-2.4,-3.6,4.0),400,3.0,(1,.88,.78)),('Fill',(2.7,-1.5,2.2),260,2.5,(.70,.84,1)),('Rim',(.2,2.3,3.2),500,2.3,(.65,.82,1))]:
  data=bpy.data.lights.new('Studio_'+name,'AREA');data.energy=power;data.shape='DISK';data.size=size;data.color=color
  ob=bpy.data.objects.new('Studio_'+name,data);stage.objects.link(ob);ob.location=loc;point_camera(ob,(0,0,1))
 data=bpy.data.cameras.new('CAM_Kai_Presentation');cam=bpy.data.objects.new('CAM_Kai_Presentation',data);stage.objects.link(cam);cam.location=(2.4,-5,2.0);data.type='ORTHO';data.ortho_scale=1.89;point_camera(cam,(0,0,.84));scene.camera=cam
 return cam,stage

def reset_pose(rig):
 rig.animation_data_clear()
 for p in rig.pose.bones:p.location=(0,0,0);p.rotation_mode='QUATERNION';p.rotation_quaternion=(1,0,0,0);p.scale=(1,1,1)
 bpy.context.view_layer.update()

def export_fbx(path,rig,meshes,animation=False):
 bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
 for o in meshes:o.select_set(True)
 bpy.context.view_layer.objects.active=rig
 bpy.ops.export_scene.fbx(filepath=path,use_selection=True,object_types={'ARMATURE','MESH'},global_scale=1,apply_unit_scale=True,apply_scale_options='FBX_SCALE_NONE',axis_forward='-Y',axis_up='Z',use_mesh_modifiers=True,mesh_smooth_type='FACE',use_tspace=True,add_leaf_bones=False,primary_bone_axis='Y',secondary_bone_axis='X',use_armature_deform_only=True,bake_anim=animation,bake_anim_use_all_actions=False,bake_anim_use_nla_strips=False,bake_anim_force_startend_keying=True,bake_anim_simplify_factor=0,path_mode='COPY',embed_textures=not animation)

def main():
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 for datablocks in [bpy.data.meshes,bpy.data.armatures,bpy.data.materials,bpy.data.actions,bpy.data.images]:
  for d in list(datablocks):
   if d.users==0:datablocks.remove(d)
 scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1;scene.render.fps=30
 log('Generating PBR maps');mats=build_materials(os.path.join(ROOT,'textures'));rig=build_rig();registry=[]
 def register(obj,weights=None,rigid=None):
  if obj.type!='MESH':raise ValueError('Expected mesh '+obj.name)
  if obj not in registry:registry.append(obj)
  if rigid:assign_groups(obj,{rigid:{v.index:1 for v in obj.data.vertices}})
  elif weights:assign_groups(obj,weights)
 ctx={'mats':mats,'register':register}
 for module in [kai_head,kai_jacket,kai_lower,kai_hands]:
  log('Building '+module.__name__);module.build(ctx)
 log(f'Finishing {len(registry)} meshes')
 for obj in registry:
  apply_modifiers(obj)
  if not obj.data.uv_layers:uv_smart(obj)
  if len(obj.vertex_groups)==0:assign_groups(obj,fallback_weights(obj))
  # Recalculate normals consistently after authored patch and shell operations.
  bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj
  bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT')
  obj.parent=rig;mod=obj.modifiers.new('Skin deformation','ARMATURE');mod.object=rig;mod.use_deform_preserve_volume=False
  obj['part_of']='Kai';obj['quality_status']='Procedural candidate / artist review required'
 log('Authoring animations');actions=kai_animation.build_actions(rig)
 for action in actions:action.use_fake_user=True
 log('Preparing studio');cam,stage=setup_stage();reset_pose(rig)
 manifest=[]
 for mat in bpy.data.materials:
  if not mat.use_nodes or mat.name.startswith('Studio_'):continue
  bs=next((n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED'),None)
  if not bs:continue
  entry={'name':mat.name,'base_color_linear':list(bs.inputs['Base Color'].default_value),'roughness':bs.inputs['Roughness'].default_value,'metallic':bs.inputs['Metallic'].default_value,'textures':{}}
  for socket,label in [('Base Color','BaseColor'),('Roughness','Roughness'),('Metallic','Metallic'),('Normal','Normal')]:
   links=bs.inputs[socket].links
   if not links:continue
   node=links[0].from_node
   if node.type=='NORMAL_MAP' and node.inputs['Color'].links:node=node.inputs['Color'].links[0].from_node
   if node.type=='TEX_IMAGE' and node.image:entry['textures'][label]='textures/'+os.path.basename(node.image.filepath)
  manifest.append(entry)
 with open(os.path.join(ROOT,'validation','materials.json'),'w') as f:json.dump(manifest,f,ensure_ascii=False,indent=2)
 # Always deliver a mesh FBX in its genuine rest pose, without a baked animation.
 scene.frame_start=1;scene.frame_end=60;scene.frame_set(1)
 log('Exporting skeletal mesh');export_fbx(os.path.join(ROOT,'exports','SK_Kai.fbx'),rig,registry,False)
 action_summary=[]
 for action in actions:
  reset_pose(rig);rig.animation_data_create();rig.animation_data.action=action
  start=int(action.frame_range[0]);end=int(action.frame_range[1]);scene.frame_start=start;scene.frame_end=end;scene.frame_set(start)
  log('Export '+action.name);export_fbx(os.path.join(ROOT,'exports','animations',action.name+'.fbx'),rig,[],True)
  action_summary.append({'name':action.name,'start':start,'end':end,'duration_seconds':(end-start)/30,'loop':bool(action.get('loop',False)),'speed_cm_s':action.get('speed_cm_s',0),'fbx':'exports/animations/'+action.name+'.fbx'})
 reset_pose(rig);scene.frame_start=1;scene.frame_end=60;scene.frame_set(1)
 # Make the saved startup view a relaxed Idle pose while retaining clean rest pose rig.
 idle=next((a for a in actions if 'Idle' in a.name),actions[0]);rig.animation_data_create();rig.animation_data.action=idle;scene.frame_end=int(idle.frame_range[1]);scene.frame_set(1)
 for img in bpy.data.images:
  if img.source=='FILE':img.pack();img.filepath=bpy.path.relpath(img.filepath,start=ROOT)
 # Embedded readme travels with .blend.
 readme=bpy.data.texts.new('READ_ME__KAI_STATUS')
 readme.write('KAI / PROCEDURAL DEVELOPMENT CANDIDATE\n\nThis is a real editable 3D asset with rig, UVs, PBR textures and 11 procedural actions. It is NOT a claim of production-final art or exact reference fidelity.\nUE5 validation is delegated to user.\nSelect RIG_Kai and use Dope Sheet > Action Editor to choose AN_Kai_* actions. All clips in-place.\nRest pose: Armature properties > Skeleton > Rest Position.\nConsult README_RU.md and validation/report.json next to this file.\nTextures packed and supplied separately. Studio collection is excluded from FBX.\n')
 for area in bpy.context.screen.areas:
  if area.type=='VIEW_3D':
   area.spaces.active.region_3d.view_distance=2.5;area.spaces.active.region_3d.view_location=(0,0,.88);area.spaces.active.overlay.show_extras=False
 bpy.ops.object.select_all(action='DESELECT');rig.select_set(True);bpy.context.view_layer.objects.active=rig
 bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'Kai_Character.blend'))
 # Mesh audit is run in neutral rest pose; animated views are rendered afterwards.
 reset_pose(rig);report={'status':'PROCEDURAL_CANDIDATE_NOT_PRODUCTION_FINAL','blender':bpy.app.version_string,'units':'metres','forward':'-Y','rig_bones':len(rig.data.bones),'mesh_objects':len(registry),'vertices':sum(len(o.data.vertices) for o in registry),'triangles':sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in registry),'materials':len(mats),'bbox_rest_m':world_bbox(registry),'actions':action_summary,'mesh_checks':[],'limitations':['No UE5 runtime validation.','Procedurally authored geometry and animation require artistic refinement.','No facial performance rig, corrective blendshapes or physics clothing.','Textures are tileable authored PBR detail, not baked high-poly sculpt maps.']}
 for o in registry:
  unweighted=0;bad_sums=0;max_inf=0
  for v in o.data.vertices:
   gs=[g for g in v.groups if g.weight>1e-5];total=sum(g.weight for g in gs);max_inf=max(max_inf,len(gs))
   unweighted+=not bool(gs);bad_sums+=abs(total-1)>.005
  report['mesh_checks'].append({'name':o.name,'vertices':len(o.data.vertices),'polygons':len(o.data.polygons),'uv_layers':len(o.data.uv_layers),'unweighted_vertices':unweighted,'weight_sum_errors':bad_sums,'max_influences':max_inf})
 report['checks_passed']=all(x['uv_layers'] and x['unweighted_vertices']==0 and x['weight_sum_errors']==0 for x in report['mesh_checks'])
 with open(os.path.join(ROOT,'validation','report.json'),'w') as f:json.dump(report,f,ensure_ascii=False,indent=2)
 log('Geometry report '+str({k:report[k] for k in ['rig_bones','mesh_objects','vertices','triangles','checks_passed']}))
 if '--skip-render' not in sys.argv:
  rig.animation_data_create();rig.animation_data.action=idle;scene.frame_set(1)
  scene.render.filepath=os.path.join(ROOT,'previews','Kai_ThreeQuarter.png');bpy.ops.render.render(write_still=True)
 log('COMPLETE')
if __name__=='__main__':main()
