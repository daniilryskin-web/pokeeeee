"""Authored patterned hoodie and undershirt for Kai, metre scale, front -Y.

The large garments use purpose-built quad surfaces, with cloth folds built into
the patterns. Small garment hardware is batched per material where possible.
"""
import math
import bpy
from mathutils import Vector
from kai_common import mesh_object, tube, ribbon, bezier_points

PI = math.pi


def build(ctx):
    mats = ctx['mats']
    result = []
    details = {}

    def spine_weights(z):
        if z <= .91:
            t = max(0.0, min(1.0, (z-.845)/.065))
            return {'pelvis': 1-t, 'spine_01': t}
        if z < 1.045:
            t = (z-.91)/.135
            return {'spine_01': 1-t, 'spine_02': t}
        t = max(0.0, min(1.0, (z-1.045)/.135))
        return {'spine_02': 1-t, 'spine_03': t}

    def sleeve_weights(t, side):
        suffix = 'l' if side > 0 else 'r'
        blend = max(0.0, min(1.0, (t-.56)/.33))
        blend = blend*blend*(3-2*blend)
        shoulder = max(0.0, min(1.0, (t+.16)/.28))
        shoulder = shoulder*shoulder*(3-2*shoulder)
        return {'upperarm_'+suffix: shoulder*(1-blend),
                'lowerarm_'+suffix: shoulder*blend, 'spine_03':1-shoulder}

    def register(ob, mode='body', side=1, rigid=None):
        if rigid:
            ctx['register'](ob, rigid=rigid)
        else:
            weights = {}
            for vert in ob.data.vertices:
                if mode == 'sleeve':
                    # Project onto the arm axis so all vertices in one ring share
                    # their hinge blend; using X alone shears the elbow rings.
                    t = ((side*vert.co.x-.170)*.185+(1.191-vert.co.z)*.223)/(.185**2+.223**2)
                    w = sleeve_weights(t, side)
                else:
                    w = spine_weights(vert.co.z)
                for bone, amount in w.items():
                    if amount > 1e-7:
                        weights.setdefault(bone, {})[vert.index] = amount
            ctx['register'](ob, weights=weights)
        result.append(ob)
        return ob

    def grid(name, points, nr, nc, material, wrap=False, mode='body', side=1, thickness=0.0, subd=0):
        faces = []
        for i in range(nr-1):
            for j in range(nc if wrap else nc-1):
                a = i*nc+j
                b = i*nc+(j+1)%nc
                face = (a, b, b+nc, a+nc)
                if mode == 'sleeve' and side > 0:
                    face = face[::-1]
                faces.append(face)
        ob = mesh_object(name, points, faces, material)
        uv = ob.data.uv_layers.new(name='UVMap')
        for poly in ob.data.polygons:
            for li in poly.loop_indices:
                vi = ob.data.loops[li].vertex_index
                u = (vi % nc)/max(1,nc-1)
                # Explicit UV seam on closed loops.
                if wrap and min(ob.data.loops[k].vertex_index%nc for k in poly.loop_indices)==0 and max(ob.data.loops[k].vertex_index%nc for k in poly.loop_indices)==nc-1:
                    u = 1.0 if vi%nc==0 else (vi%nc)/nc
                uv.data[li].uv = (u, (vi//nc)/max(1,nr-1))
        if subd:
            mod = ob.modifiers.new('Garment surface subdivision','SUBSURF')
            mod.levels = subd
            mod.render_levels = subd
        if thickness:
            mod = ob.modifiers.new('Fabric thickness','SOLIDIFY')
            mod.thickness = thickness
            mod.offset = -.3
        return register(ob, mode=mode, side=side)

    def line(name, points, radius, material='stitch', rigid=None, mode='body', side=1, sides=8):
        return register(tube(name, points, radius, mats[material], sides=sides),mode=mode,side=side,rigid=rigid)

    def batch_piece(group, material, verts, faces, rigid=None):
        data = details.setdefault(group, {'mat':material,'v':[],'f':[],'rigid':rigid})
        offset = len(data['v'])
        data['v'].extend(verts)
        data['f'].extend(tuple(v+offset for v in f) for f in faces)

    def small_box(group, center, dimensions, material='silver', rigid=None):
        x,y,z = center
        a,b,c = (v/2 for v in dimensions)
        vs = [(x-a,y-b,z-c),(x+a,y-b,z-c),(x+a,y+b,z-c),(x-a,y+b,z-c),
              (x-a,y-b,z+c),(x+a,y-b,z+c),(x+a,y+b,z+c),(x-a,y+b,z+c)]
        fs = [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
        batch_piece(group, material, vs, fs, rigid)

    profile = [(.853,.141,.075,.25),(.88,.147,.081,.28),(.94,.153,.085,.29),
               (1.005,.157,.084,.33),(1.08,.168,.087,.36),(1.15,.166,.080,.36),
               (1.2,.155,.071,.39),(1.235,.143,.066,.44)]

    def prof(z):
        for a,b in zip(profile[:-1],profile[1:]):
            if a[0] <= z <= b[0]:
                t = (z-a[0])/(b[0]-a[0])
                return [a[k]*(1-t)+b[k]*t for k in range(1,4)]
        return list(profile[0][1:] if z < profile[0][0] else profile[-1][1:])

    def torso(theta,z,folds=True):
        rx,ry,_ = prof(z)
        amount = math.sin(PI*max(0,min(1,(z-.853)/.382)))
        wrinkle = (math.sin(theta*7+z*38)*.0023 + math.sin(theta*13-z*57)*.0014)*amount
        # Folds collect at waistband and under the arm.
        wrinkle += .0065*math.exp(-((z-.905)/.043)**2)*math.sin(theta*9+z*30+.8)
        wrinkle += .0050*math.exp(-((z-1.075)/.052)**2)*math.sin(theta*5+z*80)
        if not folds: wrinkle=0
        return (math.sin(theta)*(rx+wrinkle), -math.cos(theta)*(ry+wrinkle*.7),z)

    def front_pos(x,z,offset=.0015):
        rx,ry,a = prof(z)
        theta = math.asin(max(-.98,min(.98,x/rx)))
        p = torso(theta,z)
        return (p[0],p[1]-offset,p[2])

    # Shirt: tailor-shaped rings narrow from shoulders into an open neckline.
    shirt_rows = [(.847,.127,.066),(.852,.131,.068),(.869,.132,.070),(.9,.128,.069),
                  (.95,.130,.069),(1.015,.133,.069),(1.085,.138,.071),
                  (1.14,.140,.066),(1.17,.133,.060),(1.214,.052,.041),
                  (1.239,.038,.036),(1.242,.038,.036)]
    nv = 56
    verts=[]
    for row,(z,rx,ry) in enumerate(shirt_rows):
        for j in range(nv):
            a=2*PI*j/nv
            front=max(0,math.cos(a))
            drape=.0030*math.sin(a*7+z*26)*math.sin(PI*row/(len(shirt_rows)-1))
            zz=z-.005*front if row>=9 else z+.004*math.sin(a*3+.6)*(1-row/12)
            verts.append((math.sin(a)*(rx+drape),-math.cos(a)*(ry+drape)+.003,zz))
    shirt=grid('Kai_Tshirt_Tailored',verts,len(shirt_rows),nv,mats['white'],wrap=True,thickness=.002,subd=1)
    # Round bound neckline, with a second seam.
    collar=[]
    for j in range(65):
        a=2*PI*j/64
        collar.append((.038*math.sin(a),-.036*math.cos(a)+.002,1.241-.005*max(0,math.cos(a))))
    line('Kai_Tshirt_CollarBinding',collar,.0023,'white')
    # Distinctive chest mark: double triangular embroidery, front-facing.
    tri=[(-.024,-.0718,1.151),(0,-.0755,1.119),(.024,-.0718,1.151),(-.024,-.0718,1.151)]
    line('Kai_Tshirt_EmbroideredTriangle',tri,.0020,'navy',rigid='spine_03')
    line('Kai_Tshirt_EmbroideredTriangleInner',[(-.012,-.0733,1.146),(0,-.0750,1.130),(.012,-.0733,1.146)],.0013,'navy',rigid='spine_03')
    line('Kai_Tshirt_CyanMark',[(-.012,-.074,1.153),(.012,-.074,1.153)],.0015,'cyan',rigid='spine_03')

    # The jacket is a single open pattern, with actual front opening and shaped yoke.
    zs=[.854,.857,.867,.885,.91,.938,.966,.995,1.023,1.05,1.077,1.102,1.125,1.145,1.163,1.180,1.196,1.213,1.228,1.233]
    nc=65
    verts=[]
    for row,z in enumerate(zs):
        rx,ry,opening=prof(z)
        for j in range(nc):
            theta=opening+(2*PI-2*opening)*j/(nc-1)
            p=list(torso(theta,z))
            # Shoulders sweep lower toward the armhole; centre back stays high.
            shoulder=max(0,(z-1.145)/.088)
            p[2]-=.046*abs(math.sin(theta))**2*shoulder
            # Deliberately small front asymmetry in the relaxed unzipped garment.
            p[2]+=.0026*math.sin(theta*2+.5)*math.sin(PI*row/(len(zs)-1))
            verts.append(p)
    jacket=grid('Kai_Hoodie_OpenBody',verts,len(zs),nc,mats['navy'],thickness=.0038,subd=1)
    jacket.data.materials.append(mats['navy_light'])
    for poly in jacket.data.polygons:
        row=poly.index//(nc-1); col=poly.index%(nc-1)
        if row>14 or (col<8 and row<5):poly.material_index=1

    # Ribbed elastic waistband preserves the same open-front pattern.
    verts=[]; nr=7; nc2=105
    for i in range(nr):
        z=.845+.021*i/(nr-1)
        rx,ry,opening=.149,.0845,.27
        for j in range(nc2):
            a=opening+(2*PI-2*opening)*j/(nc2-1)
            rib=.0009*math.cos(j*PI)
            verts.append(((rx+rib)*math.sin(a),-(ry+rib)*math.cos(a),z+.0015*math.sin(a*3)))
    grid('Kai_Hoodie_RibbedHem',verts,nr,nc2,mats['navy_dark'],thickness=.002)
    # Narrow pale inner hem mirrors the reference without creating a broad belt.
    hem=[]
    for j in range(65):
        a=.28+(2*PI-.56)*j/64
        hem.append((.147*math.sin(a),-.084*math.cos(a),.864))
    line('Kai_Hoodie_HemSeam',hem,.0010,'stitch')

    # Sculpted hood bowl: navy exterior, cyan lining, sewn border.
    hood_rows=[(.105,.091,.040,1.224,.019),(.106,.090,.041,1.221,.019),
               (.108,.077,.060,1.205,.016),(.102,.061,.083,1.182,.013),
               (.082,.044,.105,1.164,.009),(.052,.026,.122,1.151,.005),
               (.023,.012,.130,1.145,.002),(.004,.004,.132,1.144,.001)]
    hn=64; hverts=[]; hfaces=[]; nhr=len(hood_rows)
    for inside in (False,True):
        for i,(rx,ry,cy,z,slant) in enumerate(hood_rows):
            for j in range(hn):
                a=2*PI*j/hn
                fold=.0018*math.sin(a*7+i*.8)*math.sin(PI*i/(nhr-1))
                # The lining is offset toward the bowl cavity, including the
                # near-vertical back wall; a Z-only offset hides it externally.
                inset=min(.003,min(rx,ry)*.25) if inside else 0
                hverts.append(((rx+fold-inset)*math.sin(a),cy-(ry+fold-inset)*math.cos(a),z-slant*math.cos(a)+(.0015 if inside else 0)))
        base=(hn*nhr if inside else 0)
        for i in range(nhr-1):
            for j in range(hn):
                a=base+i*hn+j;b=base+i*hn+(j+1)%hn
                face=(a,a+hn,b+hn,b)
                if inside:face=face[::-1]
                hfaces.append(face)
    # Close physical cloth thickness at rim, not the opening.
    for j in range(hn):hfaces.append((j,(j+1)%hn,hn*nhr+(j+1)%hn,hn*nhr+j))
    hood=mesh_object('Kai_Hoodie_LinedLoweredHood',hverts,hfaces,mats['navy'])
    hood.data.materials.append(mats['cyan'])
    split=(nhr-1)*hn
    for p in hood.data.polygons:
        if split<=p.index<split*2:p.material_index=1
    uv=hood.data.uv_layers.new(name='UVMap')
    for p in hood.data.polygons:
        for li in p.loop_indices:
            vi=hood.data.loops[li].vertex_index%(hn*nhr)
            uv.data[li].uv=((vi%hn)/hn,(vi//hn)/(nhr-1))
    mod=hood.modifiers.new('Soft hood drape','SUBSURF');mod.levels=1;mod.render_levels=1
    register(hood,rigid='spine_03')
    rim=[]
    for j in range(97):
        a=2*PI*j/96
        rim.append((.105*math.sin(a),.040-.091*math.cos(a),1.225-.019*math.cos(a)))
    line('Kai_Hoodie_HoodRolledEdge',rim,.0031,'navy_light',rigid='spine_03')
    back_seam=[(0,.132,1.244),(0,.133,1.228),(0,.139,1.209),(0,.146,1.192),(0,.150,1.175),(0,.149,1.157),(0,.140,1.147)]
    line('Kai_Hoodie_HoodCentreSeam',back_seam,.001,'navy_dark',rigid='spine_03')

    # Sleeve patterns follow the actual A-pose centreline.
    def sleeve_point(t,a,side,offset=0):
        cx=.170+.185*t
        cz=1.191-(.035 if t<0 else .223)*t
        cy=.0015*math.sin(PI*max(0,t))
        if t < 0:
            # A rounded shoulder cap collapses into the yoke rather than leaving
            # the open cylindrical sleeve root visible above the shoulder.
            radius=max(.006,.064*math.sqrt(max(0,1-(t/.33)**2)))
        else:
            radius=.064+.011*math.sin(PI*t*.95)-.021*t**3-.007*t**8
            radius+=.0036*math.sin(5*a+13*t)*math.sin(PI*t)
            radius+=.0037*math.sin(29*t+3*a)*math.exp(-((t-.78)/.24)**2)
        radius+=offset
        u=Vector((.770,0,.638));v=Vector((0,1,0))
        p=Vector((cx,cy,cz))+u*(math.cos(a)*radius)+v*(math.sin(a)*radius*.96)
        return (side*p.x,p.y,p.z)

    for side,suf in [(1,'L'),(-1,'R')]:
        sn=40; ts=[-.33,-.315,-.28,-.23,-.17,-.10,-.045,0,.016,.045,.10,.17,.25,.34,.43,.52,.60,.68,.75,.81,.86,.90,.94,.975,1]
        verts=[sleeve_point(t,2*PI*j/sn,side) for t in ts for j in range(sn)]
        sleeve=grid('Kai_Hoodie_Sleeve_'+suf,verts,len(ts),sn,mats['navy'],wrap=True,mode='sleeve',side=side,thickness=.003,subd=1)
        # Running seam is placed along the rear underside.
        line('Kai_Hoodie_SleeveSeam_'+suf,[sleeve_point(i/30,PI*.63,side,.0013) for i in range(31)],.00085,'navy_dark',mode='sleeve',side=side)
        # Shaped white diagonal fabric band around the outer lower sleeve.
        verts=[]
        for i in range(6):
            for j in range(sn):
                a=2*PI*j/sn
                t=.61+.11*math.cos(a-.9)+.105*i/5
                verts.append(sleeve_point(t,a,side,.0050))
        grid('Kai_Hoodie_WhiteSleeveBand_'+suf,verts,6,sn,mats['white'],wrap=True,mode='sleeve',side=side,thickness=.0009,subd=1)
        for row in [0,1]:
            pts=[]
            for j in range(sn+1):
                a=2*PI*j/sn;t=.61+.11*math.cos(a-.9)+.105*row
                pts.append(sleeve_point(t,a,side,.0058))
            line('Kai_Hoodie_BandStitch_'+suf+str(row),pts,.00065,'stitch',mode='sleeve',side=side)
        # Rib cuffs include actual radial grooves, and follow the sleeve axis.
        verts=[];cn=64
        for row in range(8):
            t=.965+.105*row/7
            for j in range(cn):
                a=2*PI*j/cn
                rad=.0422+(.0011 if j%2 else -.0011)+.0010*math.sin(PI*row/7)
                u=Vector((.770,0,.638));v=Vector((0,1,0))
                p=Vector((.170+.185*t,0,1.191-.223*t))+rad*(u*math.cos(a)+v*math.sin(a))
                verts.append((side*p.x,p.y,p.z))
        grid('Kai_Hoodie_RibbedCuff_'+suf,verts,8,cn,mats['navy_dark'],wrap=True,mode='sleeve',side=side,thickness=.002)
        # Upper-arm inset badge lies on the forward surface of the sleeve.
        badge=[]
        for i in range(8):
            t=.22+.13*i/7
            for j in range(8):
                a=-PI/2+(-.30+.60*j/7)
                badge.append(sleeve_point(t,a,side,.0023))
        grid('Kai_Hoodie_ArmBadge_'+suf,badge,8,8,mats['navy_dark'],mode='sleeve',side=side,thickness=.001)
        # Small sleeve insignia, fitted to the curvature.
        marks=[(.237,-PI/2-.16),(.237,-PI/2+.16),(.325,-PI/2),(.237,-PI/2-.16)]
        line('Kai_Hoodie_ArmTriangle_'+suf,[sleeve_point(t,a,side,.0040) for t,a in marks],.00125,'white',mode='sleeve',side=side)
        # Cyan strap with a woven dark end below the badge.
        strap=[]
        for i in range(12):
            t=.36+.23*i/11
            for j in range(5):
                a=-PI/2+(-.11+.22*j/4)
                strap.append(sleeve_point(t,a,side,.0029))
        grid('Kai_Hoodie_CyanArmTab_'+suf,strap,12,5,mats['cyan'],mode='sleeve',side=side,thickness=.0012)
        for j in [0,1]:
            a=-PI/2+(-.083 if j==0 else .083)
            line('Kai_Hoodie_CyanTabStitch_'+suf+str(j),[sleeve_point(.37+.20*i/15,a,side,.0042) for i in range(16)],.0005,'cyan_light',mode='sleeve',side=side)

    # Zipper tape follows the open-front edge from hem to neckline.
    for side,suf in [(1,'L'),(-1,'R')]:
        points=[]
        for i in range(51):
            z=.861+.359*i/50
            rx,ry,a=prof(z)
            p=list(torso(a,z))
            p[0]*=side;p[1]-=.0022
            p[2]-=.046*math.sin(a)**2*max(0,(z-1.145)/.088)
            points.append(p)
        tape=ribbon('Kai_Hoodie_ZipTape_'+suf,points,.008,mats['navy_dark'],thickness=.0013)
        register(tape)
        line('Kai_Hoodie_ZipperCoil_'+suf,[(p[0]-side*.0022,p[1]-.001,p[2]) for p in points],.00085,'silver')
        line('Kai_Hoodie_FrontTopstitch_'+suf,[(p[0]+side*.0057,p[1]-.0003,p[2]) for p in points],.0006,'stitch')
        for i in range(78):
            z=.865+.345*i/77
            rx,ry,a=prof(z)
            x,y,z=torso(a,z)
            small_box('Kai_Hoodie_ZipperTeeth',(side*(x-.0015),y-.0038,z),(.0036,.0018,.0019))
        # Visible zipper slider and flexible cyan pull near the low end.
        z=.879 if side>0 else .868
        rx,ry,a=prof(z);x,y,z=torso(a,z);x*=side
        small_box('Kai_Hoodie_ZipperSliders',(x,y-.006,z+.006),(.008,.006,.014),'silver')
        pp=[(x,y-.009,z+.002),(x+side*.001,y-.012,z-.008),(x+side*.002,y-.013,z-.025)]
        pull=ribbon('Kai_Hoodie_MainZipPull_'+suf,pp,.0065,mats['cyan'],thickness=.002)
        register(pull)

        # Diagonal welt pocket with piped zipper, subtly inset in its pattern.
        pocket=[front_pos(side*(.094+.034*t),1.017-.075*t,.0025) for t in [i/20 for i in range(21)]]
        welt=ribbon('Kai_Hoodie_PocketWelt_'+suf,pocket,.012,mats['navy_light'],thickness=.0015)
        register(welt)
        line('Kai_Hoodie_PocketOpening_'+suf,[(p[0],p[1]-.0018,p[2]) for p in pocket],.0022,'navy_dark')
        line('Kai_Hoodie_PocketZip_'+suf,[(p[0]+side*.001,p[1]-.0032,p[2]) for p in pocket],.0007,'silver')
        p=pocket[0]
        small_box('Kai_Hoodie_PocketSliders',(p[0],p[1]-.004,p[2]-.004),(.005,.003,.008),'silver')
        # Front chest reinforcement seam.
        seam=[]
        for i in range(17):
            x=side*(.069+.079*i/16);z=1.179-.026*i/16
            seam.append(front_pos(x,z,.0019))
        line('Kai_Hoodie_ShoulderStitch_'+suf,seam,.0007,'navy_dark')

        # Eyelets and two subtly asymmetric cloth drawstrings.
        start=(side*.063,-.069,1.195)
        end=(side*(.067 if side>0 else .077),-.097,1.012 if side>0 else 1.037)
        cord=bezier_points(start,(side*.069,-.086,1.16),(side*.061,-.090,1.09),end,28)
        line('Kai_Hoodie_Drawstring_'+suf,cord,.0020,'white',sides=10)
        ring=[(start[0]+.0045*math.cos(2*PI*j/20),start[1]-.001,start[2]+.006*math.sin(2*PI*j/20)) for j in range(21)]
        line('Kai_Hoodie_DrawstringEyelet_'+suf,ring,.001,'silver',rigid='spine_03')
        aglet=[end,(end[0]+side*.0008,end[1]-.0008,end[2]-.015)]
        line('Kai_Hoodie_CyanAglet_'+suf,aglet,.0030,'cyan',sides=8)
        line('Kai_Hoodie_AgletCap_'+suf,[aglet[-1],(aglet[-1][0],aglet[-1][1],aglet[-1][2]-.002)],.0031,'silver',sides=8)

    # Back-panel stitching remains visible below the hood and strap.
    for side,suf in [(1,'L'),(-1,'R')]:
        pts=[]
        for i in range(31):
            z=.884+.282*i/30;a=PI-side*.62
            x,y,z=torso(a,z);pts.append((x,y+.0017,z))
        line('Kai_Hoodie_BackPanelSeam_'+suf,pts,.00075,'navy_dark')

    for name,data in details.items():
        ob=mesh_object(name,data['v'],data['f'],mats[data['mat']])
        # Unambiguous object-space UVs for all tiny hardware.
        uv=ob.data.uv_layers.new(name='UVMap')
        for poly in ob.data.polygons:
            for li in poly.loop_indices:
                co=ob.data.vertices[ob.data.loops[li].vertex_index].co
                uv.data[li].uv=(co.x*5+.5,co.z*2)
        for p in ob.data.polygons:p.use_smooth=False
        bevel=ob.modifiers.new('Hardware edge highlights','BEVEL');bevel.width=.00035;bevel.segments=2
        register(ob,rigid=data['rigid'])

    return result
