"""Read-only Blender/FBX validation for Kai; does not imply Unreal validation.

Usage:
  blender -b -t 2 --python source/validate_kai.py -- --root /path/to/kai_character

The source .blend is opened then inspected in memory. FBX files are imported into
fresh empty scenes. No .blend or FBX is saved or changed. Only a JSON report is
written. Running while an asset is rebuilding invalidates the report.
"""
import argparse
import hashlib
import json
import math
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

import bpy
import numpy as np
from mathutils import Matrix

EXPECTED_ACTIONS = ['Idle', 'Walk', 'Run', 'Sprint', 'Jump', 'Fall', 'Land',
                    'Crouch', 'Turn', 'Interact', 'Throw']


def fingerprint(path):
    path = Path(path)
    if not path.is_file():
        return {'exists': False}
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    stat = path.stat()
    return {'exists': True, 'bytes': stat.st_size, 'sha256': digest.hexdigest(),
            'mtime_utc': datetime.fromtimestamp(stat.st_mtime, timezone.utc).isoformat()}


def matrix_array(matrix):
    return np.array(matrix, dtype=np.float64)


def reset_pose(rig):
    rig.animation_data_create()
    rig.animation_data.action = None
    for track in rig.animation_data.nla_tracks:
        track.mute = True
    for pb in rig.pose.bones:
        pb.matrix_basis = Matrix.Identity(4)
    bpy.context.view_layer.update()


def rest_snapshot(rig):
    world = matrix_array(rig.matrix_world)
    return {bone.name: world @ matrix_array(bone.matrix_local) for bone in rig.data.bones}


def pose_snapshot(rig, rest):
    world = matrix_array(rig.matrix_world)
    poses = {bone.name: world @ matrix_array(bone.matrix) for bone in rig.pose.bones}
    deforms = {name: matrix @ np.linalg.inv(rest[name]) for name, matrix in poses.items()}
    return {'pose': poses, 'deform': deforms}


def evaluated_bounds(meshes):
    """All evaluated vertices, including armature and remaining modifiers."""
    depsgraph = bpy.context.evaluated_depsgraph_get()
    low = np.full(3, np.inf)
    high = np.full(3, -np.inf)
    nonfinite = 0
    count = 0
    shoes_low = np.inf
    for obj in meshes:
        evaluated = obj.evaluated_get(depsgraph)
        mesh = evaluated.to_mesh()
        try:
            positions = np.empty(len(mesh.vertices) * 3, dtype=np.float64)
            mesh.vertices.foreach_get('co', positions)
            positions = positions.reshape((-1, 3))
            world = matrix_array(evaluated.matrix_world)
            positions = positions @ world[:3, :3].T + world[:3, 3]
            finite = np.isfinite(positions).all(axis=1)
            nonfinite += int((~finite).sum())
            count += len(positions)
            if finite.any():
                good = positions[finite]
                low = np.minimum(low, good.min(axis=0))
                high = np.maximum(high, good.max(axis=0))
                if any(word in obj.name.lower() for word in ('shoe', 'sole', 'sneaker', 'trainer')):
                    shoes_low = min(shoes_low, float(good[:, 2].min()))
        finally:
            evaluated.to_mesh_clear()
    return {'bbox_m': [low.tolist(), high.tolist()], 'floor_min_z_m': float(low[2]),
            'shoe_floor_min_z_m': float(shoes_low) if np.isfinite(shoes_low) else None,
            'evaluated_vertices': count, 'nonfinite_vertices': nonfinite}


def mesh_checks(meshes, rig):
    bones = set(rig.data.bones.keys())
    checks = []
    for obj in meshes:
        groups = {group.index: group.name for group in obj.vertex_groups}
        unweighted = bad_sum = nonfinite_weights = overfour = maxinf = 0
        nonfinite_coordinates = 0
        for vertex in obj.data.vertices:
            weights = [group.weight for group in vertex.groups
                       if groups.get(group.group) in bones and group.weight > 1e-6]
            nonfinite_coordinates += int(not all(math.isfinite(x) for x in vertex.co))
            nonfinite_weights += sum(not math.isfinite(group.weight) for group in vertex.groups)
            if not weights:
                unweighted += 1
            elif abs(sum(weights) - 1) > 1e-4:
                bad_sum += 1
            maxinf = max(maxinf, len(weights))
            overfour += int(len(weights) > 4)
        uvfinite = True
        for layer in obj.data.uv_layers:
            values = np.empty(len(layer.data) * 2)
            layer.data.foreach_get('uv', values)
            uvfinite &= bool(np.isfinite(values).all())
        checks.append({'name': obj.name, 'vertices': len(obj.data.vertices),
                       'polygons': len(obj.data.polygons),
                       'triangles': sum(max(0, len(poly.vertices)-2) for poly in obj.data.polygons),
                       'uv_layers': len(obj.data.uv_layers), 'finite_uvs': uvfinite,
                       'material_slots': len(obj.material_slots),
                       'armature_modifier': any(mod.type == 'ARMATURE' and mod.object == rig for mod in obj.modifiers),
                       'unweighted_vertices': unweighted, 'weight_sum_errors': bad_sum,
                       'nonfinite_weights': nonfinite_weights, 'nonfinite_coordinates': nonfinite_coordinates,
                       'max_influences': maxinf, 'vertices_over_four_influences': overfour})
    return checks


def similarity_alignment(source_rest, imported_rest):
    """Fit one scale/rotation/translation from bind bone heads, never per pose."""
    common = sorted(set(source_rest) & set(imported_rest))
    src = np.array([source_rest[n][:3, 3] for n in common])
    imp = np.array([imported_rest[n][:3, 3] for n in common])
    srcc, impc = src.mean(axis=0), imp.mean(axis=0)
    x, y = imp - impc, src - srcc
    u, _, vt = np.linalg.svd(x.T @ y)
    correction = np.eye(3)
    correction[2, 2] = np.linalg.det(vt.T @ u.T)
    rotation = vt.T @ correction @ u.T
    rotated = x @ rotation.T
    scale = float((rotated * y).sum() / (x * x).sum())
    translation = srcc - scale * rotation @ impc
    transform = np.eye(4)
    transform[:3, :3] = scale * rotation
    transform[:3, 3] = translation
    aligned = imp @ transform[:3, :3].T + translation
    errors = np.linalg.norm(aligned - src, axis=1)
    return transform, {'common_bones': len(common), 'scale_imported_to_source': scale,
                       'translation_m': translation.tolist(),
                       'rotation_degrees': math.degrees(math.acos(float(np.clip((np.trace(rotation)-1)/2, -1, 1)))),
                       'raw_head_max_error_m': float(np.linalg.norm(src-imp, axis=1).max()),
                       'aligned_head_max_error_m': float(errors.max())}


def snapshot_delta(source, imported, transform):
    inverse = np.linalg.inv(transform)
    heads = []
    deformation = []
    poses = []
    for name in source['pose']:
        if name not in imported['pose']:
            continue
        head = transform @ imported['pose'][name][:, 3]
        heads.append(float(np.linalg.norm(head[:3] - source['pose'][name][:3, 3])))
        normalized = transform @ imported['deform'][name] @ inverse
        deformation.append(float(np.max(np.abs(source['deform'][name] - normalized))))
        poses.append(float(np.max(np.abs(source['pose'][name] - transform @ imported['pose'][name]))))
    return {'head_max_error_m': max(heads, default=None),
            'pose_matrix_max_abs_error': max(poses, default=None),
            'deformation_matrix_max_abs_error': max(deformation, default=None)}


def import_fbx(path, fps):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.context.scene.render.fps = fps
    bpy.context.scene.render.fps_base = 1
    bpy.ops.import_scene.fbx(filepath=str(path), use_anim=True, anim_offset=1.0,
                             automatic_bone_orientation=False, ignore_leaf_bones=False,
                             force_connect_children=False)
    rigs = [obj for obj in bpy.context.scene.objects if obj.type == 'ARMATURE']
    if len(rigs) != 1:
        raise RuntimeError(f'Expected exactly one imported armature; got {len(rigs)}')
    return rigs[0]


def restore_connect_flags(rig, source_flags):
    """FBX does not encode Blender's edit-bone connected flag.

    Blender infers connected heads when reconstructing tails, even with
    force_connect_children=False. A newly connected pelvis silently ignores its
    valid keyed translation. Restore source flags in the temporary import scene;
    this changes neither files nor keyframe values.
    """
    changed = [n for n, flag in source_flags.items()
               if n in rig.data.bones and rig.data.bones[n].use_connect != flag]
    if changed:
        bpy.ops.object.select_all(action='DESELECT')
        rig.select_set(True)
        bpy.context.view_layer.objects.active = rig
        bpy.ops.object.mode_set(mode='EDIT')
        for name in changed:
            rig.data.edit_bones[name].use_connect = source_flags[name]
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.context.view_layer.update()
    return changed


def run(args):
    root = args.root.resolve()
    blend = root / 'Kai_Character.blend'
    fbx_model = root / 'exports/SK_Kai.fbx'
    inputs = [blend, fbx_model] + [root / 'exports/animations' / f'AN_Kai_{name}.fbx' for name in EXPECTED_ACTIONS]
    report = {'validator_version': 1, 'started_utc': datetime.now(timezone.utc).isoformat(),
              'validator_sha256': fingerprint(__file__)['sha256'],
              'blender_version': bpy.app.version_string, 'scope': 'Blender native and FBX roundtrip only; UE5 not tested',
              'input_files': {str(p.relative_to(root)): fingerprint(p) for p in inputs},
              'failures': [], 'warnings': [],
              'limitations': ['Numerical checks do not assess reference fidelity, artistic quality, self-intersection, topology edge-flow or foot sliding.',
                              'Deformation is sampled at key fractions and pose markers, not every frame.',
                              'FBX is reimported into Blender, not Unreal Engine.',
                              'Imported bone tail lengths may differ because FBX stores transforms rather than Blender edit-bone tips.']}
    failures, warnings = report['failures'], report['warnings']
    missing = [name for name, stat in report['input_files'].items() if not stat['exists']]
    if missing:
        raise FileNotFoundError('Missing required assets: ' + ', '.join(missing))
    bpy.ops.wm.open_mainfile(filepath=str(blend))
    rigs = [obj for obj in bpy.context.scene.objects if obj.type == 'ARMATURE']
    if len(rigs) != 1:
        raise RuntimeError(f'Expected exactly one source armature; got {len(rigs)}')
    rig = rigs[0]
    meshes = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH' and
              (obj.get('part_of') == 'Kai' or obj.name.startswith('Kai_') or
               any(mod.type == 'ARMATURE' and mod.object == rig for mod in obj.modifiers))]
    scene = bpy.context.scene
    fps = scene.render.fps / scene.render.fps_base
    reset_pose(rig)
    source_rest = rest_snapshot(rig)
    source_parents = {bone.name: bone.parent.name if bone.parent else None for bone in rig.data.bones}
    source_connect = {bone.name: bool(bone.use_connect) for bone in rig.data.bones}
    checks = mesh_checks(meshes, rig)
    report['source'] = {'fps': fps, 'unit_scale': scene.unit_settings.scale_length,
                        'armature': rig.name, 'bones': len(source_rest), 'bone_names': sorted(source_rest),
                        'root_bones': [n for n, parent in source_parents.items() if not parent],
                        'mesh_objects': len(meshes), 'vertices': sum(c['vertices'] for c in checks),
                        'triangles': sum(c['triangles'] for c in checks),
                        'rest_bounds': evaluated_bounds(meshes), 'mesh_checks': checks}
    for item in checks:
        if any(item[key] for key in ('unweighted_vertices', 'weight_sum_errors', 'nonfinite_weights',
                                    'nonfinite_coordinates', 'vertices_over_four_influences')):
            failures.append('Source mesh weight/finite check: ' + item['name'])
        if not item['uv_layers'] or not item['finite_uvs']:
            failures.append('Source mesh UV check: ' + item['name'])
        if not item['armature_modifier'] or not item['material_slots']:
            failures.append('Source mesh missing armature modifier/material: ' + item['name'])
    actions = [bpy.data.actions.get('AN_Kai_'+name) for name in EXPECTED_ACTIONS]
    source_snapshots = {}
    report['actions'] = []
    for expected, action in zip(EXPECTED_ACTIONS, actions):
        if action is None:
            failures.append('Missing action AN_Kai_' + expected)
            continue
        name = action.name
        start, end = map(float, action.frame_range)
        markers = [(marker.name, marker.frame) for marker in action.pose_markers]
        frames = sorted(set([round(start+(end-start)*i/(args.samples-1)) for i in range(args.samples)] +
                            [int(frame) for _, frame in markers]))
        reset_pose(rig)
        rig.animation_data.action = action
        snapshots = {}
        samples = []
        for frame in frames:
            scene.frame_set(frame)
            bpy.context.view_layer.update()
            snapshots[frame] = pose_snapshot(rig, source_rest)
            bounds = evaluated_bounds(meshes)
            bounds['frame'] = frame
            samples.append(bounds)
            if bounds['nonfinite_vertices']:
                failures.append(f'Nonfinite evaluated vertices: {name} frame {frame}')
        source_snapshots[name] = {'snapshots': snapshots, 'start': start, 'end': end}
        endpoint = snapshot_delta(snapshots[frames[0]], snapshots[frames[-1]], np.eye(4))
        loop = bool(action.get('loop', False))
        if loop and (endpoint['head_max_error_m'] > 1e-4 or endpoint['deformation_matrix_max_abs_error'] > 1e-4):
            failures.append(f'Loop endpoint mismatch: {name}')
        floor = min(sample['floor_min_z_m'] for sample in samples)
        if floor < -.01:
            warnings.append(f'{name}: sampled geometry reaches {floor:.4f} m below floor (1 cm tolerance)')
        root_heads = [sample['pose']['root'][:3, 3] for sample in snapshots.values() if 'root' in sample['pose']]
        root_extent = np.ptp(np.array(root_heads), axis=0).tolist() if root_heads else None
        item = {'name': name, 'start': start, 'end': end, 'duration_seconds': (end-start)/fps,
                'loop': loop, 'speed_cm_s': action.get('speed_cm_s', 0),
                'pose_markers': markers, 'samples': samples, 'endpoint_delta': endpoint,
                'root_translation_extent_m': root_extent,
                'max_ik_target_correction_m': action.get('max_ik_target_correction_m', None)}
        report['actions'].append(item)
        print(f'[Kai validate] {name}: sampled {len(samples)} frames; floor {floor:.4f} m', flush=True)
    if not args.skip_roundtrip:
        print('[Kai validate] FBX mesh roundtrip', flush=True)
        imported = import_fbx(fbx_model, round(fps))
        reset_pose(imported)
        imported_rest = rest_snapshot(imported)
        transform, alignment = similarity_alignment(source_rest, imported_rest)
        mesh_import_to_source = transform.copy()
        imported_meshes = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']
        imported_names = set(imported_rest)
        imported_parents = {bone.name: bone.parent.name if bone.parent else None for bone in imported.data.bones}
        imported_checks = mesh_checks(imported_meshes, imported)
        report['fbx_mesh_roundtrip'] = {
            'bones': len(imported_rest), 'missing_bones': sorted(set(source_rest)-imported_names),
            'extra_bones': sorted(imported_names-set(source_rest)),
            'parent_mismatches': [n for n in source_parents if imported_parents.get(n) != source_parents[n]],
            'alignment': alignment, 'mesh_objects': len(imported_meshes),
            'vertices': sum(c['vertices'] for c in imported_checks),
            'triangles': sum(c['triangles'] for c in imported_checks),
            'bounds': evaluated_bounds(imported_meshes),
            'mesh_issues': [c for c in imported_checks if c['unweighted_vertices'] or c['weight_sum_errors'] or
                            c['max_influences'] > 4 or not c['armature_modifier'] or not c['uv_layers']]}
        mesh_result = report['fbx_mesh_roundtrip']
        if any(mesh_result[k] for k in ('missing_bones', 'extra_bones', 'parent_mismatches', 'mesh_issues')):
            failures.append('FBX skeletal mesh bone/weight/UV mismatch')
        if alignment['aligned_head_max_error_m'] > 1e-4:
            failures.append('FBX skeletal mesh bind-pose mismatch')
        if abs(alignment['scale_imported_to_source']-1) > 1e-4:
            warnings.append(f'FBX import requires scale normalization {alignment["scale_imported_to_source"]:.8f}')
        if mesh_result['triangles'] != report['source']['triangles']:
            warnings.append('FBX/source triangle counts differ; investigate triangulation or evaluated modifiers')
        report['fbx_animation_roundtrip'] = []
        for name, source in source_snapshots.items():
            print('[Kai validate] FBX animation roundtrip ' + name, flush=True)
            imported = import_fbx(root / 'exports/animations' / (name+'.fbx'), round(fps))
            connect_adjustments = restore_connect_flags(imported, source_connect)
            action = imported.animation_data.action if imported.animation_data else None
            if action is None:
                failures.append('Imported FBX has no action: ' + name)
                continue
            imported_rest = rest_snapshot(imported)
            # An armature-only FBX has no mesh BindPose. Blender imports its first
            # animated pose as edit-bone rest. Its animated WORLD matrices are
            # still comparable to source; using this temporary rest for skinning
            # would manufacture a false mismatch. Reuse the one canonical mesh
            # bind-pose transform established by the skeletal-mesh roundtrip.
            transform = mesh_import_to_source
            canonical_import_rest = {n: np.linalg.inv(transform) @ m for n, m in source_rest.items()}
            rest_errors = [float(np.linalg.norm((transform @ imported_rest[n])[:3, 3]-source_rest[n][:3, 3]))
                           for n in set(source_rest) & set(imported_rest)]
            start, end = map(float, action.frame_range)
            sampled = []
            for frame, source_snapshot in source['snapshots'].items():
                imported_frame = start + (frame-source['start'])
                bpy.context.scene.frame_set(int(imported_frame), subframe=imported_frame % 1)
                bpy.context.view_layer.update()
                delta = snapshot_delta(source_snapshot, pose_snapshot(imported, canonical_import_rest), transform)
                sampled.append({'source_frame': frame, 'imported_frame': imported_frame, **delta})
            result = {'name': name, 'imported_action_name': action.name, 'bones': len(imported_rest),
                      'missing_bones': sorted(set(source_rest)-set(imported_rest)),
                      'extra_bones': sorted(set(imported_rest)-set(source_rest)),
                      'start': start, 'end': end, 'duration_seconds': (end-start)/fps,
                      'bind_pose_note': 'Armature-only FBX imports with first-frame rest; compare animated world matrices against canonical mesh bind pose.',
                      'restored_blender_bone_connect_flags': connect_adjustments,
                      'connect_flag_note': 'Blender FBX importer reconstructs bone tails and infers connected flags. Source flags restored in memory to prevent keyed pelvis translation being ignored; FBX files and curves are unchanged.',
                      'imported_rest_head_max_difference_from_mesh_m': max(rest_errors),
                      'normalization': 'Same global unit/axis transform as main skeletal mesh; no per-animation pose fitting.',
                      'samples': sampled,
                      'max_head_error_m': max(s['head_max_error_m'] for s in sampled),
                      'max_pose_matrix_error': max(s['pose_matrix_max_abs_error'] for s in sampled),
                      'max_deformation_matrix_error': max(s['deformation_matrix_max_abs_error'] for s in sampled)}
            if result['missing_bones'] or result['extra_bones']:
                failures.append('FBX animation bone mismatch: ' + name)
            if abs((end-start)-(source['end']-source['start'])) > .01:
                failures.append('FBX animation duration mismatch: ' + name)
            if result['max_head_error_m'] > 1e-3 or result['max_deformation_matrix_error'] > 1e-3 or result['max_pose_matrix_error'] > 1e-3:
                failures.append('FBX animation pose mismatch: ' + name)
            report['fbx_animation_roundtrip'].append(result)
    else:
        warnings.append('FBX roundtrip skipped by command-line option')
    changed = [str(p.relative_to(root)) for p in inputs if fingerprint(p) != report['input_files'][str(p.relative_to(root))]]
    report['inputs_changed_during_validation'] = changed
    if changed:
        failures.append('Input assets changed during validation; rerun after build completes')
    report['completed_utc'] = datetime.now(timezone.utc).isoformat()
    report['status'] = 'FAIL' if failures else ('PASS_WITH_WARNINGS' if warnings else 'PASS')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--samples', type=int, default=9)
    parser.add_argument('--skip-roundtrip', action='store_true')
    args = parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
    if args.samples < 2:
        parser.error('--samples must be at least 2')
    output = args.output or args.root / 'validation/blender_validation.json'
    try:
        result = run(args)
    except Exception:
        result = {'status': 'ERROR', 'completed_utc': datetime.now(timezone.utc).isoformat(),
                  'scope': 'Blender only; UE5 not tested', 'traceback': traceback.format_exc()}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    print('[Kai validate] ' + result['status'] + ' ' + str(output), flush=True)
    if result['status'] in ('FAIL', 'ERROR'):
        raise SystemExit(1)
