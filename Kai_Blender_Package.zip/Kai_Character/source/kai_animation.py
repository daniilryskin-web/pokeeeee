"""Frame-baked, authored procedural locomotion and gestures for Kai.

These clips are an artist-tunable starting set, not motion capture or a claim of
production-ready animation.  No constraints or control rig are needed at runtime.
Coordinate system: metres, Z up, character faces -Y; positive X is character left.
"""
import math
import bpy
from mathutils import Vector, Matrix, Quaternion

FPS = 30
TAU = 2.0 * math.pi


def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def smooth(x):
    x = clamp(x)
    return x * x * (3.0 - 2.0 * x)


def lerp(a, b, t):
    return a * (1.0 - t) + b * t


def curve(t, pairs):
    if t <= pairs[0][0]:
        return pairs[0][1]
    for (ta, a), (tb, b) in zip(pairs[:-1], pairs[1:]):
        if t <= tb:
            return lerp(a, b, smooth((t - ta) / (tb - ta)))
    return pairs[-1][1]


def vec_curve(t, pairs):
    return Vector(tuple(curve(t, [(f, p[i]) for f, p in pairs]) for i in range(3)))


def rotation(x=0.0, y=0.0, z=0.0):
    # Rotations are radians in the undeformed world frame.  Compose yaw last.
    return (Quaternion((0, 0, 1), z) @ Quaternion((1, 0, 0), x)
            @ Quaternion((0, 1, 0), y))


def mat_at(point, orientation):
    result = orientation.to_matrix().to_4x4()
    result.translation = point
    return result


def descendant_of(bone, names):
    while bone is not None:
        if bone.name in names:
            return True
        bone = bone.parent
    return False


class PoseWriter:
    """Compose global rotations, then bake closed-form two-bone IK to FK keys."""
    def __init__(self, rig):
        self.rig = rig
        self.bones = list(rig.data.bones)
        self.bones.sort(key=lambda b: len(b.parent_recursive))
        self.rest = {b.name: b.matrix_local.copy() for b in self.bones}
        self.rest_q = {n: m.to_quaternion() for n, m in self.rest.items()}
        self.rest_inv = {n: m.inverted() for n, m in self.rest.items()}
        self.parents = {b.name: b.parent.name if b.parent else None for b in self.bones}
        self.previous_q = {}
        self.max_ik_correction = 0.0
        for pb in rig.pose.bones:
            pb.rotation_mode = 'QUATERNION'

    def start(self):
        self.basis = {b.name: Matrix.Identity(4) for b in self.bones}
        self.pose = {}
        self.locked = set()
        self.extra_loc = Vector((0, 0, 0))

    def delta(self, name, x=0, y=0, z=0, q=None):
        if name not in self.rest:
            return
        q = q or rotation(x, y, z)
        r = self.rest_q[name]
        translation = self.basis[name].translation.copy()
        self.basis[name] = (r.inverted() @ q @ r).to_matrix().to_4x4()
        self.basis[name].translation = translation

    def local_rotation(self, name, x=0, y=0, z=0):
        if name in self.rest:
            translation = self.basis[name].translation.copy()
            self.basis[name] = rotation(x, y, z).to_matrix().to_4x4()
            self.basis[name].translation = translation

    def translate(self, name, vector):
        if name in self.rest:
            self.basis[name].translation = self.rest_q[name].inverted() @ Vector(vector)

    def compose(self):
        for b in self.bones:
            n = b.name
            if n in self.locked:
                continue
            par = self.parents[n]
            if par:
                self.pose[n] = self.pose[par] @ self.rest_inv[par] @ self.rest[n] @ self.basis[n]
            else:
                self.pose[n] = self.rest[n] @ self.basis[n]

    def chain(self, upper, lower, end, target, pole, end_rotation=None):
        if any(n not in self.rest for n in (upper, lower, end)):
            return
        par = self.parents[upper]
        parent_delta = (self.pose[par] @ self.rest_inv[par]) if par else Matrix.Identity(4)
        origin = parent_delta @ self.rest[upper].translation
        a = self.rig.data.bones[upper].length
        b = self.rig.data.bones[lower].length
        offset = Vector(target) - origin
        distance = offset.length
        aim = offset.normalized()
        limit = a + b - 0.00005
        safe_d = clamp(distance, abs(a-b) + 0.0001, limit)
        self.max_ik_correction = max(self.max_ik_correction, abs(distance-safe_d))
        target = origin + aim * safe_d
        along = (a*a - b*b + safe_d*safe_d) / (2.0*safe_d)
        across = math.sqrt(max(0, a*a - along*along))
        side = Vector(pole) - origin
        side -= aim * side.dot(aim)
        if side.length < 0.000001:
            side = aim.cross(Vector((1, 0, 0)))
        side.normalize()
        joint = origin + aim*along + side*across
        base_q = parent_delta.to_quaternion()
        for name, head, tail in ((upper, origin, joint), (lower, joint, target)):
            initial_q = base_q @ self.rest_q[name]
            current_axis = initial_q @ Vector((0, 1, 0))
            desired_axis = (tail-head).normalized()
            desired_q = current_axis.rotation_difference(desired_axis) @ initial_q
            self.pose[name] = mat_at(head, desired_q)
            self.locked.add(name)
        if end_rotation is None:
            end_rotation = base_q
        self.pose[end] = mat_at(target, end_rotation @ self.rest_q[end])
        self.locked.add(end)

    def bake(self, frame):
        self.compose()  # Rebuild toes/fingers below the solved limbs.
        for bone in self.bones:
            n = bone.name
            par = self.parents[n]
            if par:
                basis = self.rest_inv[n] @ self.rest[par] @ self.pose[par].inverted() @ self.pose[n]
            else:
                basis = self.rest_inv[n] @ self.pose[n]
            loc, q, scale = basis.decompose()
            if n in self.previous_q and self.previous_q[n].dot(q) < 0:
                q.negate()
            self.previous_q[n] = q.copy()
            pb = self.rig.pose.bones[n]
            # Suppress roundoff-induced nonzero translations on connected joints.
            pb.location = tuple(0.0 if abs(v) < 1e-7 else v for v in loc)
            pb.rotation_quaternion = q
            pb.scale = (1, 1, 1)
            pb.keyframe_insert(data_path='rotation_quaternion', frame=frame, group=n)
            if n in ('root', 'pelvis'):
                pb.keyframe_insert(data_path='location', frame=frame, group=n)


def foot_height(pitch):
    # Sole contact envelope: heel 6 cm behind ankle, toe 17 cm in front.
    return 0.105 * math.cos(pitch) + max(0.17*math.sin(pitch), -0.06*math.sin(pitch))


def gait_foot(phase, stride, stance, clearance):
    phase %= 1.0
    if phase <= stance:
        s = phase / stance
        y = stride * (s - 0.5)
        pitch = curve(s, [(0, -0.13), (.16, 0), (.72, 0), (1, .32)])
        z = foot_height(pitch)
        toe = -curve(s, [(0, 0), (.78, 0), (1, .23)])
    else:
        q = (phase-stance) / (1-stance)
        # Hermite endpoints share the stance's backwards foot speed.
        m = stride * (1-stance) / stance
        y = (stride*.5*(2*q**3-3*q*q+1) - stride*.5*(-2*q**3+3*q*q)
             + m*(q**3-2*q*q+q) + m*(q**3-q*q))
        pitch = curve(q, [(0, .32), (.24, .38), (.58, -.10), (1, -.13)])
        z = foot_height(pitch) + clearance * math.sin(math.pi*q)**1.35
        toe = -curve(q, [(0, .23), (.30, 0), (1, 0)])
    return y, z, pitch, toe


def fingers(w, side, amount=0.15, thumb=0.08):
    # Curl towards the palm (-Y at rest), independent of phalanx bone roll.
    sign = 1 if side == 'l' else -1
    axis = Vector((sign*.796, 0, .605)).normalized()
    for finger, multiplier in (('index', .80), ('middle', 1.0), ('ring', 1.10), ('pinky', 1.18)):
        for segment, factor in ((1, .65), (2, 1), (3, .65)):
            w.delta(f'{finger}_{segment:02d}_{side}', q=Quaternion(axis, -sign*amount*factor*multiplier))
    for segment, factor in ((1, .45), (2, .7), (3, .5)):
        w.delta(f'thumb_{segment:02d}_{side}', q=Quaternion(axis, -sign*thumb*factor))


def resting_arms(w, swing=0, elbow=.13, lateral=0, hand=.04):
    for side, sign in (('l', 1), ('r', -1)):
        w.delta('clavicle_'+side, x=-.015, z=sign*lateral)
        w.delta('upperarm_'+side, x=sign*swing, y=sign*.45)
        w.delta('lowerarm_'+side, x=-elbow)
        w.delta('hand_'+side, x=hand)
        fingers(w, side)


def add_leg(w, side, target, pitch=0, toe=0, yaw=0, knee_out=0):
    sign = 1 if side == 'l' else -1
    qyaw = rotation(z=yaw)
    target = qyaw @ Vector(target)
    pelvis = w.pose['pelvis'].translation
    pole = pelvis + qyaw @ Vector((sign*(.10+knee_out), -.8, -.30))
    w.delta('ball_'+side, x=toe)
    w.chain('thigh_'+side, 'calf_'+side, 'foot_'+side, target, pole,
            end_rotation=qyaw @ rotation(x=pitch, z=-sign*.025))


def basic_idle(w, t, crouch=False):
    phase = TAU*t
    breath = math.sin(phase)
    sway = math.sin(phase)*.004
    if crouch:
        w.translate('pelvis', (sway, .037, -.185+.003*breath))
        w.delta('pelvis', x=.07, z=.015*math.sin(phase))
        w.delta('spine_01', x=.18)
        w.delta('spine_02', x=.08-.015*breath)
        w.delta('spine_03', x=-.06)
        w.delta('neck_01', x=-.10)
        w.delta('head', x=-.07, z=.025*math.sin(phase))
        resting_arms(w, swing=.03*math.sin(phase), elbow=.54)
        w.delta('upperarm_l', x=-.17, y=.34)
        w.delta('upperarm_r', x=-.17, y=-.34)
        w.compose()
        add_leg(w, 'l', (.125, -.025, .105), knee_out=.08)
        add_leg(w, 'r', (-.125, -.025, .105), knee_out=.08)
    else:
        w.translate('pelvis', (sway, 0, -.008+.002*breath))
        w.delta('pelvis', y=.012*math.sin(phase))
        w.delta('spine_01', x=.008*breath, y=-.006*math.sin(phase))
        w.delta('spine_02', x=-.014*breath)
        w.delta('spine_03', x=.008*breath)
        w.delta('neck_01', y=.018*math.sin(phase-.25)-.018*math.sin(-.25))
        w.delta('head', x=.014*math.sin(phase+.45), z=.025*math.sin(phase))
        resting_arms(w, swing=.012*math.sin(phase), elbow=.15+.025*breath,
                     lateral=.008*breath)
        w.compose()
        add_leg(w, 'l', (.098, -.012, .105))
        add_leg(w, 'r', (-.098, .018, .105))


def locomotion(w, t, kind):
    if kind == 'Walk':
        stride, stance, clearance, pelvis_z, bounce, lean, arm, bend = (.36, .61, .065, -.041, .008, .035, .34, .19)
    elif kind == 'Run':
        stride, stance, clearance, pelvis_z, bounce, lean, arm, bend = (.42, .38, .15, -.072, .018, .14, .59, 1.03)
    else:
        stride, stance, clearance, pelvis_z, bounce, lean, arm, bend = (.47, .30, .20, -.097, .020, .23, .78, 1.13)
    ph = TAU*t
    hip_yaw = .055*math.sin(ph)
    w.translate('pelvis', (.008*math.sin(ph), -.006, pelvis_z-bounce*math.cos(2*ph)))
    w.delta('pelvis', x=.012, y=.026*math.sin(ph), z=hip_yaw)
    w.delta('spine_01', x=lean*.6, z=-hip_yaw*.7)
    w.delta('spine_02', x=lean*.4, y=-.015*math.sin(ph), z=-hip_yaw*.65)
    w.delta('spine_03', x=-lean*.12)
    w.delta('neck_01', x=-lean*.3, z=.015*math.sin(ph))
    w.delta('head', x=-lean*.26, z=.020*math.sin(ph-.2))
    # Left leg forward coincides with right shoulder forward.
    swing = arm * math.cos(ph + .20)
    resting_arms(w, swing=swing, elbow=bend)
    for side, sign in (('l', 1), ('r', -1)):
        w.delta('clavicle_'+side, x=sign*.045*math.cos(ph), z=sign*.025)
        w.delta('upperarm_'+side, x=sign*swing, y=sign*(.39 if kind != 'Walk' else .44))
        w.delta('lowerarm_'+side, x=-bend-.14*math.sin(ph+sign*.5))
        w.delta('hand_'+side, x=.08, z=sign*.03*math.sin(ph))
        fingers(w, side, .22 if kind == 'Walk' else .43, .20)
    w.compose()
    for side, offset, sign in (('l', 0, 1), ('r', .5, -1)):
        y, z, pitch, toe = gait_foot(t+offset, stride, stance, clearance)
        add_leg(w, side, (sign*.096, y, z), pitch, toe)


def jumping(w, t):
    # Root stays stationary. Pelvis trajectory is visual jump height, suitable for
    # in-place gameplay after blending/control with the UE movement component.
    crouch = curve(t, [(0, 0), (.20, 1), (.34, 0), (1, 0)])
    lift = curve(t, [(0, 0), (.27, 0), (.54, .27), (.73, .33), (1, .20)])
    w.translate('pelvis', (0, -.025*crouch, -.010-.16*crouch+lift))
    w.delta('pelvis', x=.06*crouch)
    w.delta('spine_01', x=.16*crouch)
    w.delta('spine_02', x=.04*crouch)
    w.delta('spine_03', x=-.06*crouch)
    w.delta('head', x=-.10*crouch-.04*lift)
    arm = curve(t, [(0, 0), (.22, .52), (.42, -.82), (.68, -.34), (1, -.22)])
    elbow = curve(t, [(0, .16), (.24, .32), (.42, .80), (.72, .59), (1, .50)])
    resting_arms(w, elbow=elbow)
    for side, sign in (('l', 1), ('r', -1)):
        w.delta('upperarm_'+side, x=arm, y=sign*.30)
        fingers(w, side, .26)
    w.compose()
    tuck = curve(t, [(0, 0), (.31, 0), (.54, .15), (.77, .20), (1, .11)])
    foot_lift = curve(t, [(0, 0), (.29, 0), (.54, .21), (.75, .24), (1, .13)])
    foot_lift = max(foot_lift, lift + .40*tuck)
    pitch = curve(t, [(0, 0), (.25, 0), (.34, .35), (.65, .22), (1, .05)])
    for side, sign in (('l', 1), ('r', -1)):
        add_leg(w, side, (sign*.10, tuck, foot_height(pitch)+foot_lift), pitch)


def falling(w, t):
    ph = TAU*t
    w.translate('pelvis', (.004*math.sin(ph), 0, -.012+.004*math.sin(ph)))
    w.delta('spine_01', x=.08)
    w.delta('spine_02', x=-.035)
    w.delta('head', x=-.06, z=.015*math.sin(ph))
    resting_arms(w, elbow=.50+.025*math.sin(ph))
    for side, sign in (('l', 1), ('r', -1)):
        w.delta('upperarm_'+side, x=-.18, y=sign*.12, z=sign*.025*math.sin(ph))
        fingers(w, side, .13)
    w.compose()
    for side, sign in (('l', 1), ('r', -1)):
        add_leg(w, side, (sign*.115, .115+sign*.02, .19+.007*math.sin(ph+sign*.4)), .10)


def landing(w, t):
    impact = curve(t, [(0, .10), (.22, 1), (.52, .42), (1, 0)])
    w.translate('pelvis', (0, -.015*impact, -.010-.185*impact))
    w.delta('pelvis', x=.035*impact)
    w.delta('spine_01', x=.20*impact)
    w.delta('spine_02', x=.08*impact)
    w.delta('spine_03', x=-.045*impact)
    w.delta('neck_01', x=-.08*impact)
    w.delta('head', x=-.10*curve(t, [(0, 0), (.31, 1), (.63, .20), (1, 0)]))
    resting_arms(w, elbow=.16+.43*impact)
    for side, sign in (('l', 1), ('r', -1)):
        w.delta('upperarm_'+side, x=-.21*impact, y=sign*(.45-.17*impact))
    w.compose()
    for side, sign in (('l', 1), ('r', -1)):
        y = lerp(.04, -.010 if sign == 1 else .018, smooth(t))
        pitch = curve(t, [(0, .12), (.22, 0), (1, 0)])
        add_leg(w, side, (sign*.103, y, foot_height(pitch)), pitch)


def turning(w, t):
    angle = math.pi*.5*smooth(t)
    anticipation = math.sin(math.pi*t)
    w.translate('pelvis', (.014*math.sin(TAU*t), 0, -.022-.018*anticipation))
    w.delta('pelvis', z=angle)
    w.delta('spine_01', z=.10*math.sin(math.pi*t))
    w.delta('spine_02', z=.10*math.sin(math.pi*t))
    w.delta('neck_01', z=.09*math.sin(math.pi*t))
    w.delta('head', z=.14*math.sin(math.pi*t))
    resting_arms(w, swing=.16*math.sin(TAU*t), elbow=.19)
    w.compose()
    for side, sign, start, end in (('r', -1, .08, .53), ('l', 1, .43, .92)):
        q = clamp((t-start)/(end-start))
        yaw = math.pi*.5*smooth(q)
        z = .105+.065*math.sin(math.pi*q)
        add_leg(w, side, (sign*.103, 0, z), yaw=yaw)


def interaction(w, t):
    reach = curve(t, [(0, 0), (.38, 1), (.67, 1), (1, 0)])
    hold = curve(t, [(0, 0), (.39, 0), (.50, 1), (.65, 1), (.78, 0), (1, 0)])
    w.translate('pelvis', (0, -.012*reach, -.012))
    w.delta('pelvis', z=-.06*reach)
    w.delta('spine_01', x=.025*reach, z=-.05*reach)
    w.delta('spine_02', x=.07*reach)
    w.delta('head', x=.10*reach, z=-.05*reach)
    resting_arms(w, elbow=.17)
    fingers(w, 'r', .12+.69*hold, .08+.32*hold)
    w.compose()
    add_leg(w, 'l', (.098, -.012, .105))
    add_leg(w, 'r', (-.098, .018, .105))
    shoulder = w.pose['upperarm_r'].translation
    base = w.pose['hand_r'].translation.copy()
    target = base.lerp(Vector((-.20, -.31, 1.12)), reach)
    # Wrist rotates from relaxed down to a forward-facing grasp.
    rest_axis = w.rest_q['hand_r'] @ Vector((0, 1, 0))
    desired_axis = Vector((-.08, -1, -.05)).normalized()
    q = Quaternion().slerp(rest_axis.rotation_difference(desired_axis), reach)
    w.chain('upperarm_r', 'lowerarm_r', 'hand_r', target,
            shoulder+Vector((-.24, -.13, -.20)), end_rotation=q)


def throwing(w, t):
    anticipation = curve(t, [(0, 0), (.36, 1), (.48, .7), (.61, 0), (1, 0)])
    release = curve(t, [(0, 0), (.35, 0), (.56, 1), (.69, .60), (1, 0)])
    follow = curve(t, [(0, 0), (.55, 0), (.72, 1), (1, 0)])
    yaw = .30*anticipation-.32*release-.12*follow
    w.translate('pelvis', (.025*anticipation-.030*release, -.018*release, -.023-.016*anticipation))
    w.delta('pelvis', z=yaw*.65)
    w.delta('spine_01', x=-.07*anticipation+.10*follow, z=yaw*.35)
    w.delta('spine_02', x=-.08*anticipation+.12*follow, z=yaw*.3)
    w.delta('spine_03', z=-.07*release)
    w.delta('neck_01', x=.03*anticipation, z=-yaw*.6)
    w.delta('head', x=-.07*anticipation, z=-yaw*.25)
    resting_arms(w, elbow=.18)
    w.delta('upperarm_l', x=-.37*anticipation+.34*release, y=.40)
    w.delta('lowerarm_l', x=-.20-.34*anticipation-.35*release)
    grip = curve(t, [(0, .16), (.17, .65), (.49, .65), (.55, .05), (.75, .08), (1, .16)])
    fingers(w, 'r', grip, grip*.5)
    w.compose()
    add_leg(w, 'l', (.105, -.025, .105))
    add_leg(w, 'r', (-.105, .055, foot_height(.035*release)), pitch=.035*release)
    shoulder = w.pose['upperarm_r'].translation
    base = w.pose['hand_r'].translation.copy()
    target = vec_curve(t, [(0, tuple(base)), (.17, (-.26, -.09, 1.12)),
                           (.35, (-.26, .15, 1.39)), (.45, (-.245, .12, 1.42)),
                           (.56, (-.20, -.280, 1.36)), (.71, (.035, -.25, 1.05)),
                           (.84, (-.16, -.11, .90)), (1, tuple(base))])
    pole = shoulder + Vector((-.34, .03-.12*release, .035+.16*anticipation))
    rest_axis = w.rest_q['hand_r'] @ Vector((0, 1, 0))
    desired_axis = vec_curve(t, [(0, tuple(rest_axis)), (.35, (0, .55, .75)),
                                (.46, (0, .30, .90)), (.56, (.04, -1, .20)),
                                (.71, (.32, -.60, -.45)), (1, tuple(rest_axis))]).normalized()
    w.chain('upperarm_r', 'lowerarm_r', 'hand_r', target, pole,
            end_rotation=rest_axis.rotation_difference(desired_axis))


CLIPS = [
    # name, duration in frames, loop, speed cm/s, evaluator
    ('Idle', 120, True, 0, lambda w, t: basic_idle(w, t)),
    ('Walk', 32, True, 55.33, lambda w, t: locomotion(w, t, 'Walk')),
    ('Run', 24, True, 138.16, lambda w, t: locomotion(w, t, 'Run')),
    ('Sprint', 20, True, 235.0, lambda w, t: locomotion(w, t, 'Sprint')),
    ('Jump', 36, False, 0, jumping),
    ('Fall', 30, True, 0, falling),
    ('Land', 24, False, 0, landing),
    ('Crouch', 90, True, 0, lambda w, t: basic_idle(w, t, True)),
    ('Turn', 36, False, 0, turning),
    ('Interact', 60, False, 0, interaction),
    ('Throw', 42, False, 0, throwing),
]


def build_actions(rig):
    """Create and return the eleven AN_Kai_* Actions on a matching humanoid rig.

    Existing unrelated actions are untouched. Existing AN_Kai_* actions created
    by this module are replaced on an intentional rebuild.
    """
    rig.animation_data_create()
    writer = PoseWriter(rig)
    actions = []
    scene = bpy.context.scene
    scene.render.fps = FPS
    for name, duration, loop, speed, evaluate in CLIPS:
        action_name = 'AN_Kai_'+name
        old = bpy.data.actions.get(action_name)
        if old:
            if rig.animation_data.action == old:
                rig.animation_data.action = None
            bpy.data.actions.remove(old)
        action = bpy.data.actions.new(action_name)
        action.use_fake_user = True
        action['kai_authorship'] = 'Authored procedural FK bake from analytic IK; artist review required'
        action['loop'] = loop
        action['fps'] = FPS
        action['frame_start'] = 1
        action['frame_end'] = duration+1
        action['speed_cm_s'] = speed
        action['root_translation'] = 'in-place; root translation is zero'
        if name == 'Turn':
            action['turn_angle_deg'] = 90
            action['turn_note'] = 'Stationary root; 90 degree yaw carried by pelvis and planted stepping feet'
        if name == 'Jump':
            action['jump_note'] = 'Visual jump height in pelvis; adapt/blend for gameplay capsule trajectory'
        rig.animation_data.action = action
        writer.previous_q = {}
        writer.max_ik_correction = 0.0
        for i in range(duration+1):
            writer.start()
            evaluate(writer, i/duration)
            writer.bake(i+1)
        for fcurve in action.fcurves:
            for key in fcurve.keyframe_points:
                key.interpolation = 'LINEAR'
            if loop:
                modifier = fcurve.modifiers.new('CYCLES')
                modifier.mode_before = 'REPEAT'
                modifier.mode_after = 'REPEAT'
        action['max_ik_target_correction_m'] = round(writer.max_ik_correction, 6)
        if name == 'Throw':
            action.pose_markers.new('Release').frame = round(duration*.56)+1
        elif name == 'Jump':
            action.pose_markers.new('Takeoff').frame = round(duration*.30)+1
            action.pose_markers.new('Apex').frame = round(duration*.73)+1
        elif name == 'Land':
            action.pose_markers.new('Impact').frame = round(duration*.20)+1
        elif name == 'Interact':
            action.pose_markers.new('Grasp').frame = round(duration*.48)+1
        if name in ('Walk', 'Run', 'Sprint'):
            action.pose_markers.new('Foot_L').frame = 1
            action.pose_markers.new('Foot_R').frame = duration//2+1
        actions.append(action)
        print(f'[Kai animation] {action_name}: 1-{duration+1}, loop={loop}, max IK correction={writer.max_ik_correction:.5f}m')
    rig.animation_data.action = actions[0]
    scene.frame_start = 1
    scene.frame_end = int(actions[0]['frame_end'])
    scene.frame_set(1)
    rig['kai_animation_note'] = '11 authored procedural clips, frame-baked at 30 fps; tune contact, style and gameplay transitions with an animator.'
    return actions
