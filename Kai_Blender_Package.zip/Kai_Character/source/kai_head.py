"""Authored parametric head for Kai. Coordinates in metres, front = -Y.
Facial mesh is sculpted ring topology; hair consists of individually authored
curved closed lens sections. This is a procedural art candidate, not a hand sculpt.
"""
import bpy, math, random, bmesh
from mathutils import Vector
from kai_common import mesh_object, tube, bezier_points


def build(ctx):
    mats=ctx['mats']; output=[]
    def add(ob,rigid='head',weights=None):
        output.append(ob); ctx['register'](ob,weights=weights,rigid=rigid if weights is None else None); return ob
    def uv_grid(ob,cols,rows):
        uv=ob.data.uv_layers.new(name='UVMap')
        for poly in ob.data.polygons:
            for li in poly.loop_indices:
                vi=ob.data.loops[li].vertex_index; uv.data[li].uv=((vi%cols)/(cols-1),(vi//cols)/max(1,rows-1))
    def mat_copy(key,name,color,rough=.4):
        m=mats[key].copy();m.name=name
        if m.use_nodes:
            p=next((n for n in m.node_tree.nodes if n.type=='BSDF_PRINCIPLED'),None)
            if p:
                for link in list(p.inputs['Base Color'].links):m.node_tree.links.remove(link)
                p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough
        m.diffuse_color=(*color,1);return m
    lidmat=mat_copy('skin_shadow','Kai_Eyelid_WarmInk',(.028,.012,.016),.5)
    mouthmat=mat_copy('skin_shadow','Kai_Lip_Crease',(.29,.10,.080),.48)
    browmat=mat_copy('hair_shadow','Kai_Brow_SilverGrey',(.13,.105,.12),.56)
    iris_dark=mat_copy('iris','Kai_Iris_OuterInk',(.014,.053,.135),.24)
    iris_mid=mat_copy('iris','Kai_Iris_Azure',(.026,.235,.65),.22)
    iris_light=mat_copy('iris','Kai_Iris_Cyan',(.12,.65,.98),.22)
    iris_blue=mat_copy('iris','Kai_Iris_Striae',(.035,.37,.84),.24)
    hairline=mat_copy('hair_shadow','Kai_Hair_FineCrease',(.51,.52,.58),.5)
    eye_glint=mat_copy('white','Kai_Eye_Catchlight',(.95,.985,1),.16)
    # Horizontal facial sections. Front faces use a flattened superellipse;
    # Gaussian displacement creates integrated bridge, tip, cheeks and lips.
    sections=[
      (1.285,.009,.048,.026),(1.291,.026,.058,.034),(1.300,.036,.066,.041),
      (1.312,.052,.074,.049),(1.326,.069,.080,.058),(1.340,.083,.085,.066),
      (1.352,.094,.088,.073),(1.365,.099,.090,.080),(1.378,.103,.092,.085),
      (1.392,.105,.094,.090),(1.406,.106,.096,.094),(1.420,.106,.098,.098),
      (1.434,.106,.099,.101),(1.448,.105,.100,.103),(1.462,.104,.100,.104),
      (1.477,.101,.099,.104),(1.491,.094,.095,.099),(1.505,.084,.087,.091),
      (1.518,.069,.073,.077),(1.528,.049,.052,.057),(1.535,.027,.030,.032),
      (1.538,.004,.005,.006)]
    def sec(z):
        for a,b in zip(sections,sections[1:]):
            if a[0]<=z<=b[0]:
                t=(z-a[0])/(b[0]-a[0]);return [a[i]*(1-t)+b[i]*t for i in range(1,4)]
        return sections[0][1:] if z<sections[0][0] else sections[-1][1:]
    def face_y(x,z):
        rx,df,db=sec(z);q=min(.9999,abs(x)/rx)
        y=-df*(1-q*q)**.27
        nose=.0175*math.exp(-(x/.011)**2-((z-1.389)/.010)**2)+.007*math.exp(-(x/.009)**2-((z-1.408)/.024)**2)
        nose+=.004*math.exp(-(x/.017)**2-((z-1.382)/.007)**2)
        lips=.0025*math.exp(-(x/.023)**4-((z-1.353)/.006)**2)
        cheek=.0025*math.exp(-((abs(x)-.066)/.024)**2-((z-1.389)/.02)**2)
        socket=.003*math.exp(-((abs(x)-.047)/.029)**4-((z-1.426)/.017)**4)
        return y-nose-lips-cheek+socket
    verts=[];faces=[];N=128
    for z,rx,df,db in sections:
        for j in range(N+1):
            a=2*math.pi*j/N;x=rx*math.sin(a);c=math.cos(a)
            y=face_y(x,z) if c>=0 else db*(-c)**.8
            verts.append((x,y,z))
    for i in range(len(sections)-1):
        for j in range(N):
            a=i*(N+1)+j;faces.append((a,a+1,a+N+2,a+N+1))
    faces.extend([tuple(range(N,-1,-1)),tuple((len(sections)-1)*(N+1)+j for j in range(N+1))])
    head=mesh_object('Kai_Head_QuadSculpt',verts,faces,mats['skin']);uv_grid(head,N+1,len(sections))
    sub=head.modifiers.new('Facial continuity','SUBSURF');sub.levels=1;sub.render_levels=1
    add(head)
    # Neck with several rings to interpolate deformation into head and chest.
    neckrings=[(1.205,.043,.038,.010),(1.220,.039,.035,.008),(1.242,.034,.031,.006),(1.270,.034,.032,.004),(1.292,.037,.034,.002),(1.306,.041,.036,0)]
    v=[];f=[];n=40
    for z,rx,ry,cy in neckrings:
        for j in range(n+1):
            a=2*math.pi*j/n;v.append((rx*math.sin(a),cy-ry*math.cos(a),z))
    for i in range(len(neckrings)-1):
        for j in range(n):
            a=i*(n+1)+j;f.append((a,a+1,a+n+2,a+n+1))
    neck=mesh_object('Kai_Neck_Deform',v,f,mats['skin']);uv_grid(neck,n+1,len(neckrings))
    weights={'neck_01':{},'head':{},'spine_03':{}}
    for i,p in enumerate(v):
        z=p[2];wh=max(0,min(1,(z-1.27)/.035));ws=max(0,min(.7,(1.24-z)/.05));weights['head'][i]=wh;weights['spine_03'][i]=ws;weights['neck_01'][i]=1-wh-ws
    add(neck,weights=weights)
    # Almond white surfaces: radial quad rings fitted to actual sculpt surface.
    def eye_z(theta):
        s=math.sin(theta);return (.017 if s>0 else .0125)*math.copysign(abs(s)**1.45,s)
    def eye_depth(x,z,cx):
        qx=(x-cx)/.034;qz=(z-1.426-(x-cx)*(1 if cx>0 else -1)*.10)/.017
        return face_y(x,z)-.0012-.0065*max(0,1-qx*qx-qz*qz)
    def patch(name,cx,cz,rx,rz,material,offset=.0004,n=64,rings=5):
        vv=[];ff=[]
        for k in range(rings+1):
            r=max(.0001,k/rings)
            for j in range(n+1):
                t=2*math.pi*j/n;x=cx+rx*r*math.cos(t);z=cz+rz*r*math.sin(t)
                ecx=.046 if cx>0 else -.046;dx=(x-ecx)*(1 if cx>0 else -1);h=max(0,1-(dx/.034)**2)**.725
                z=max(1.426+dx*.10-.0125*h+.00015,min(1.426+dx*.10+.017*h-.00015,z))
                vv.append((x,eye_depth(x,z,.046 if cx>0 else -.046)-offset,z))
        for k in range(rings):
            for j in range(n):
                a=k*(n+1)+j;ff.append((a,a+1,a+n+2,a+n+1))
        ob=mesh_object(name,vv,[tuple(reversed(face)) for face in ff],material);uv_grid(ob,n+1,rings+1);return ob
    for s,label in [(1,'L'),(-1,'R')]:
        cx=s*.046;cz=1.426;v=[];f=[];n=72;nr=7
        for k in range(nr+1):
            r=max(.0001,k/nr)
            for j in range(n+1):
                t=2*math.pi*j/n;dx=.034*math.cos(t)*r;x=cx+s*dx;z=cz+eye_z(t)*r+dx*.10
                v.append((x,eye_depth(x,z,cx),z))
        for k in range(nr):
            for j in range(n):
                a=k*(n+1)+j;f.append((a,a+1,a+n+2,a+n+1))
        ob=mesh_object('Kai_Eye_Almond_'+label,v,[tuple(reversed(face)) for face in f] if s>0 else f,mats['eye_white']);uv_grid(ob,n+1,nr+1);add(ob)
        iris=patch('Kai_Iris_Layered_'+label,cx-s*.001,cz+.0003,.0142,.0148,iris_dark,offset=.00065,n=96,rings=12)
        for mat in [iris_mid,iris_light,iris_blue]:iris.data.materials.append(mat)
        for p in iris.data.polygons:
            ring=p.index//96;angle=(p.index%96+.5)*2*math.pi/96
            if ring>=11:p.material_index=0
            elif math.sin(angle)<-.15:p.material_index=2 if (p.index%5)!=0 else 3
            else:p.material_index=1 if (p.index%4)!=0 else 3
        add(iris)
        pupil=patch('Kai_Pupil_'+label,cx-s*.001,cz+.0018,.0058,.0080,mats['pupil'],offset=.0012,n=48,rings=3);add(pupil)
        glint=patch('Kai_Catchlight_Main_'+label,cx-s*.005,cz+.0088,.0030,.0038,eye_glint,offset=.00165,n=32,rings=3);add(glint)
        glint=patch('Kai_Catchlight_Secondary_'+label,cx+s*.0044,cz-.0064,.0012,.0016,eye_glint,offset=.00165,n=24,rings=2);add(glint)
        # Upper eyeliner is a designed tapered closed tube, with outer corner lift.
        pts=[];rads=[]
        for j in range(37):
            t=math.pi*j/36;dx=.034*math.cos(t);x=cx+s*dx;z=cz+eye_z(t)+dx*.10
            pts.append((x,eye_depth(x,z,cx)-.0005,z));rads.append(.0008+.0015*math.sin(t)**.6)
        add(tube('Kai_Upper_Eyelid_'+label,pts,rads,lidmat,sides=8,aspect=.65))
        pts=[];rads=[]
        for j in range(25):
            t=math.pi+math.pi*j/24;dx=.034*math.cos(t);x=cx+s*dx;z=cz+eye_z(t)+dx*.10
            pts.append((x,eye_depth(x,z,cx)-.00035,z));rads.append(.00035+.0002*math.sin(math.pi*j/24))
        add(tube('Kai_Lower_Eyelid_'+label,pts,rads,mouthmat,sides=8,aspect=.7))
        # Soft lid crease and elegant silver brow.
        brow=[];br=[]
        for j in range(17):
            t=j/16;x=s*(.020+.064*t);z=1.460+.007*math.sin(math.pi*t)-.003*t
            brow.append((x,face_y(x,z)-.0018,z));br.append(.0005+.0022*math.sin(math.pi*t)**.65)
        add(tube('Kai_Brow_'+label,brow,br,browmat,sides=8,aspect=.55))
        # Nose alar creases sit in the integrated nose, with a tiny nostril edge.
        nostril=[]
        for j in range(9):
            t=j/8;x=s*(.004+.006*t);z=1.382-.0008*math.sin(math.pi*t)
            nostril.append((x,face_y(x,z)-.0003,z))
        add(tube('Kai_Nostril_'+label,nostril,[.00025+.00015*math.sin(math.pi*j/8) for j in range(9)],mouthmat,sides=6,aspect=.6))
    # Restrained half smile follows the real muzzle surface.
    pts=[];rads=[]
    for j in range(33):
        t=j/32;x=-.022+.044*t;z=1.353+.0025*((x/.022)**2)+.0012*(t-.5)
        pts.append((x,face_y(x,z)-.0005,z));rads.append(.00015+.00045*math.sin(math.pi*t)**.55)
    add(tube('Kai_Mouth_SoftSmile',pts,rads,mouthmat,sides=8,aspect=.65))
    # Custom ear concha/helix nested elliptical rings in a tilted plane.
    for s,label in [(1,'L'),(-1,'R')]:
        v=[];f=[];n=48
        for k,r in enumerate([.001,.28,.53,.72,.88,1.0]):
            for j in range(n+1):
                a=2*math.pi*j/n;xx=.0125*math.cos(a)*(1+.18*math.sin(a));zz=.026*math.sin(a)
                x=s*(.102+r*xx);z=1.403+r*zz;y=-.006+r*.010*math.cos(a)
                # concave centre, rolled raised outer helix
                y += [.007,.005,.001,-.004,-.006,-.001][k]
                v.append((x,y,z))
        for k in range(5):
            for j in range(n):
                a=k*(n+1)+j;f.append((a,a+1,a+n+2,a+n+1))
        ear=mesh_object('Kai_Ear_Helix_'+label,v,[tuple(reversed(face)) for face in f] if s>0 else f,mats['skin']);ear.data.materials.append(mats['skin_shadow'])
        for p in ear.data.polygons:
            if p.index//n in (1,2):p.material_index=1
        uv_grid(ear,n+1,6);sol=ear.modifiers.new('Ear thickness','SOLIDIFY');sol.thickness=.003
        add(ear)
        pts=[]
        for j in range(24):
            a=-1.3+3.7*j/23;pts.append((s*(.103+.006*math.cos(a)),-.010,1.404+.018*math.sin(a)))
        add(tube('Kai_Ear_Antihelix_'+label,pts,.0017,mats['skin'],sides=8))
    # Hair foundation is a closed scalp shell with low nape and open forehead.
    v=[];f=[];N=80;R=18
    for k in range(R+1):
        t=max(.002,k/R)
        for j in range(N+1):
            a=2*math.pi*j/N;front=max(0,math.cos(a));back=max(0,-math.cos(a));end=1.94-.90*front+.20*back;ph=t*end
            v.append((.113*math.sin(ph)*math.sin(a),.009-.106*math.sin(ph)*math.cos(a),1.468+.101*math.cos(ph)))
    for k in range(R):
        for j in range(N):
            a=k*(N+1)+j;f.append((a,a+1,a+N+2,a+N+1))
    scalp=mesh_object('Kai_Hair_Underlayer',v,[tuple(reversed(face)) for face in f],mats['hair_shadow']);uv_grid(scalp,N+1,R+1);add(scalp)
    # Closed, tapering lens ribbons; each has a broad face, soft central ridge,
    # bevel-like edge and underneath shadow, rather than cone primitives.
    def lock(name,controls,width,thick=.006,normal=None):
        ps=[Vector(p) for p in bezier_points(*controls,count=21)];v=[];f=[];sides=12;crease=[]
        for i,p in enumerate(ps):
            t=i/(len(ps)-1);tan=(ps[min(i+1,len(ps)-1)]-ps[max(i-1,0)]).normalized()
            nn=Vector(normal) if normal else Vector((p.x,(p.y-.005), (p.z-1.458)*.75))
            nn=(nn-tan*nn.dot(tan)).normalized();uu=nn.cross(tan).normalized()
            # broad middle and pointed, curved final 15%.
            profile=(.48+.70*math.sin(math.pi*t)**.7)*(1-t**3.8)
            profile=max(.012,profile);w=width*.5*profile;h=thick*profile
            for j in range(sides+1):
                a=2*math.pi*j/sides;co=math.cos(a);si=math.sin(a)
                lift=h*(si if si>=0 else si*.48)
                v.append(tuple(p+uu*w*co+nn*lift))
            if 3<=i<=17:crease.append(tuple(p+uu*w*.24+nn*h*.989))
        for i in range(len(ps)-1):
            for j in range(sides):
                a=i*(sides+1)+j;f.append((a,a+1,a+sides+2,a+sides+1))
        f.extend([tuple(range(sides,-1,-1)),tuple((len(ps)-1)*(sides+1)+j for j in range(sides+1))])
        ob=mesh_object('Kai_Hair_'+name,v,f,mats['hair']);ob.data.materials.append(mats['hair_shadow'])
        for p in ob.data.polygons:
            if p.index<(len(ps)-1)*sides and p.index%sides>=7:p.material_index=1
        uv_grid(ob,sides+1,len(ps));add(ob)
        if name.startswith(('Fringe','Crown','Temple')):
            add(tube('Kai_Hair_Strand_'+name,crease,[.00010+.00020*math.sin(math.pi*j/(len(crease)-1)) for j in range(len(crease))],hairline,sides=5))
        return ob
    # Back and side underlayers, authored in scalp polar coordinates.
    rng=random.Random(1729)
    def polar(a,z,rad=.113):
        return (rad*math.sin(a),.009-rad*.94*math.cos(a),z)
    for layer,(zroot,ztip,rroot,rtip,count) in enumerate([(1.535,1.434,.072,.116,13),(1.493,1.419,.103,.116,13)]):
        for j in range(count):
            a=.94+(2*math.pi-1.88)*j/(count-1);da=rng.uniform(-.12,.12);z=ztip+rng.uniform(-.008,.009)
            c=[polar(a-.16,zroot,rroot),polar(a-.11,zroot+.016,rroot+.023),polar(a+.08,z+.028,rtip+.007),polar(a+da,z,rtip+rng.uniform(.004,.014))]
            lock('Layer%d_%02d'%(layer,j),c,.027+rng.uniform(-.003,.004),.0055)
    # Crown sweeps create raised layered volume and a readable part.
    for j in range(9):
        a=1.15+(2*math.pi-2.3)*j/8
        c=[(.016,.008,1.565),polar(a-.20,1.601,.041),polar(a+.10,1.548+.008*math.sin(j*1.7),.113),polar(a+.15,1.503+.012*math.sin(j*1.9),.128)]
        lock('Crown_%02d'%j,c,.038,.007)
    # Asymmetrical forehead locks; tips intentionally clear the eye centres.
    front_locks=[
      ([(-.005,-.018,1.576),(-.046,-.050,1.593),(-.083,-.104,1.514),(-.094,-.091,1.447)],.040,.007),
      ([(.011,-.022,1.579),(-.015,-.063,1.579),(-.060,-.120,1.503),(-.051,-.121,1.447)],.043,.008),
      ([(.021,-.018,1.581),(.007,-.080,1.573),(-.017,-.124,1.508),(-.006,-.122,1.463)],.036,.007),
      ([(.031,-.012,1.579),(.057,-.061,1.574),(.065,-.114,1.511),(.042,-.121,1.466)],.038,.007),
      ([(.040,-.003,1.576),(.081,-.029,1.566),(.106,-.077,1.489),(.095,-.083,1.435)],.034,.0065),
      ([(-.019,-.011,1.568),(-.081,-.037,1.548),(-.117,-.064,1.478),(-.109,-.064,1.422)],.033,.006),
      ([(.004,-.037,1.575),(-.019,-.090,1.550),(-.035,-.132,1.485),(-.057,-.119,1.438)],.032,.006),
      ([(.024,-.029,1.582),(.042,-.073,1.570),(.029,-.122,1.516),(.013,-.124,1.484)],.029,.006),
    ]
    for j,(c,w,h) in enumerate(front_locks):lock('Fringe_%02d'%j,c,w,h,normal=(0,-1,.18))
    # Side flicks carry the silhouette outward in soft curved blades.
    for s in (-1,1):
        for j in range(3):
            z=1.515-j*.033
            c=[(s*.078,-.019,z+.035),(s*.112,-.044,z+.024),(s*.132,-.045,z-.005),(s*(.137-j*.004),-.052,z+.003)]
            lock('Temple_%s_%d'%('L' if s>0 else 'R',j),c,.026,.005,normal=(s*.65,-.6,.1))
    # Two low, sweeping cowlicks, not vertical spikes.
    lock('Cowlick_A',[(.012,.013,1.564),(-.001,.009,1.613),(-.032,.012,1.620),(-.048,.008,1.599)],.010,.0025,normal=(0,-1,0))
    lock('Cowlick_B',[(.018,.022,1.565),(.026,.031,1.592),(.052,.030,1.601),(.063,.020,1.588)],.009,.0025,normal=(0,-1,0))
    # Extend the rear layers into a tapered nape. Front fringe and temples stay
    # fixed; the original spherical scalp stopped too high behind the ears.
    for ob in output:
        if ob.name.startswith('Kai_Hair_'):
            for vertex in ob.data.vertices:
                x,y,z=vertex.co
                rear=max(0.0,min(1.0,y/.085))
                low=max(0.0,min(1.0,(1.530-z)/.100))
                vertex.co.z-=.065*rear*low
    # Weld periodic seams while preserving per-loop UV coordinates. This avoids
    # split shading at the centre of the sculpt and leaves hair as closed solids.
    for ob in output:
        bm=bmesh.new();bm.from_mesh(ob.data)
        bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-7)
        bm.to_mesh(ob.data);bm.free();ob.data.update()
    return output
