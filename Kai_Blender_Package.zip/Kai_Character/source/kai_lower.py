"""Kai lower outfit: tailored branched trousers, authored trainer surfaces and webbing.

The shared waist/crotch bridge makes trousers one continuous quad-dominant garment.
Dimensions are metres. All details are geometry with UVs; no primitive operators.
"""
import math
import bpy
from mathutils import Vector
from kai_common import mesh_object, uv_smart, tube, ribbon


def build(ctx):
    mats = ctx['mats']
    objects = []

    def add(obj, rigid=None, weights=None, unwrap=False):
        if unwrap or not obj.data.uv_layers:
            uv_smart(obj)
        if rigid == 'weighted_leg':
            weights = leg_weights(obj)
            rigid = None
        ctx['register'](obj, weights=weights, rigid=rigid)
        objects.append(obj)
        return obj

    def sub(obj, levels=1):
        mod = obj.modifiers.new('Tailored surface smoothing', 'SUBSURF')
        mod.levels = levels
        mod.render_levels = levels
        return obj

    def detail(name, points, radius, mat, rigid=None, sides=8):
        return add(tube('Kai_'+name, points, radius, mats[mat], sides=sides), rigid=rigid)

    def panel(name, points, mat, rigid, thickness=.0015, bevel=.001):
        obj = mesh_object('Kai_'+name, points, [tuple(range(len(points)))], mats[mat])
        if thickness:
            mod = obj.modifiers.new('Panel thickness', 'SOLIDIFY'); mod.thickness = thickness
        if bevel:
            mod = obj.modifiers.new('Soft stitched edge', 'BEVEL'); mod.width = bevel; mod.segments = 2
        return add(obj, rigid=rigid, unwrap=True)

    def leg_weights(obj):
        weights = {}
        for v in obj.data.vertices:
            side = 'l' if v.co.x >= 0 else 'r'
            z = v.co.z
            if z > .76:
                p = min(1.0, max(0.0, (z-.76)/.085))
                pairs = [('pelvis', p), ('thigh_'+side, 1-p)]
            elif z > .405:
                p = min(1.0, max(0.0, (z-.405)/.115))
                p = p*p*(3-2*p)
                pairs = [('thigh_'+side,p),('calf_'+side,1-p)]
            else:
                pairs = [('calf_'+side,1)]
            for bone, weight in pairs:
                if weight > 0: weights.setdefault(bone,{})[v.index] = weight
        return weights

    # The pelvis loft bifurcates through one shared saddle rather than intersecting tubes.
    verts=[]; faces=[]; n=40
    pelvis_profiles=[(.864,.142,.077),(.858,.146,.081),(.842,.151,.085),(.821,.153,.087),(.801,.151,.087)]
    for z,rx,ry in pelvis_profiles:
        for j in range(n):
            a=2*math.pi*j/n
            verts.append((rx*math.sin(a),-ry*math.cos(a),z))
    for row in range(len(pelvis_profiles)-1):
        for j in range(n):
            a=row*n+j; b=row*n+(j+1)%n
            faces.append((a,b,b+n,a+n))
    base=(len(pelvis_profiles)-1)*n
    bridge=[]
    for j in range(1,12):
        t=j/12
        bridge.append(len(verts))
        verts.append((0,.087*math.cos(math.pi*t),.801-.077*math.sin(math.pi*t)))
    # Deliberately varied profiles describe cloth tension around knees and cuffs.
    profiles=[
        (.752,.079,.078, .000),(.720,.081,.078,-.001),
        (.685,.079,.076,-.004),(.647,.077,.073,-.008),
        (.610,.074,.068,-.011),(.575,.070,.065,-.014),
        (.543,.066,.062,-.017),(.516,.061,.061,-.022),
        (.494,.057,.057,-.026),(.479,.060,.058,-.023),
        (.463,.063,.055,-.018),(.447,.060,.056,-.012),
        (.426,.059,.060,-.005),(.401,.063,.064,.001),
        (.371,.065,.064,.005),(.338,.063,.064,.007),
        (.306,.060,.061,.007),(.278,.057,.057,.006),
        (.253,.055,.053,.005),(.232,.052,.052,.004),
        (.217,.055,.049,.004),(.203,.052,.047,.003),
        (.190,.047,.044,.002),(.181,.049,.043,.001),
        (.171,.043,.039,.001),(.161,.038,.036,.001),
        (.153,.037,.035,.001)]
    for sign,side in [(1,'l'),(-1,'r')]:
        if sign==1:
            previous=[base+j for j in range(21)]+bridge
        else:
            previous=[base]+[base+40-j for j in range(1,21)]+bridge
        for row,(z,rx,ry,cy) in enumerate(profiles):
            current=[]
            for j in range(32):
                angle=math.radians(-30+j*12) if j<=20 else math.radians(210+(j-20)*10)
                crease=(.0016*math.sin(5*angle+row*.61)+.0010*math.sin(9*angle-row*.83))
                # Slanted, asymmetric folds around the knee and lower hem.
                crease+=.0062*math.exp(-((z-.47)/.075)**2)*math.cos(2.3*angle+row*1.23)
                crease+=.0066*math.exp(-((z-.21)/.05)**2)*math.sin(2.8*angle-row*1.28)
                crease+=.0024*math.exp(-((z-.62)/.08)**2)*math.sin(2.0*angle+row*.85)
                cx=.086+(.098-.086)*max(0,min(1,(.84-z)/.70))
                dz=.0018*math.sin(3*angle+row*.6)*math.sin(math.pi*min(1,row/6))
                current.append(len(verts))
                verts.append((sign*(cx+(rx+crease)*math.sin(angle)),cy-(ry+crease)*math.cos(angle),z+dz))
            for j in range(32):
                f=(previous[j],previous[(j+1)%32],current[(j+1)%32],current[j])
                faces.append(f if sign==1 else f[::-1])
            previous=current
    trousers=mesh_object('Kai_Trousers_TailoredContinuous',verts,[f[::-1] for f in faces],mats['navy'])
    sub(trousers,1)
    add(trousers,weights=leg_weights(trousers),unwrap=True)

    # Waistband, fly and slanted hip pocket openings.
    def ellipse_band(name, cx,cy, z0,z1,rx,ry,mat,bone,segments=48,rib=False):
        vv=[]; ff=[]
        for z in [z0,z0+.002,z1-.002,z1]:
            for j in range(segments):
                a=2*math.pi*j/segments
                r=(.0014 if j%2==0 else -.0005) if rib else 0
                vv.append((cx+(rx+r)*math.sin(a),cy-(ry+r)*math.cos(a),z))
        for k in range(3):
            for j in range(segments):
                a=k*segments+j; b=k*segments+(j+1)%segments
                ff.append((a,b,b+segments,a+segments))
        obj=mesh_object('Kai_'+name,vv,[f[::-1] for f in ff],mats[mat]);sub(obj,1)
        return add(obj,rigid=bone,unwrap=True)

    ellipse_band('Waistband',0,0,.846,.871,.147,.083,'navy_dark','pelvis')
    detail('Waistband_Seam',[(.148*math.sin(t),-.084*math.cos(t),.851) for t in [2*math.pi*j/72 for j in range(73)]],.0007,'stitch','pelvis')
    detail('Fly_Stitch',[(.006,-.087,.85),(.006,-.090,.824),(.006,-.091,.799),(.001,-.091,.783)],.00065,'navy_light','pelvis')
    for sign,side in [(1,'l'),(-1,'r')]:
        thigh='thigh_'+side; calf='calf_'+side
        ellipse_band('Ankle_RibCuff_'+side,sign*.098,.001,.133,.165,.037,.035,'navy_dark',calf,segments=64,rib=True)
        for h in [.137,.160]:
            detail('Cuff_Seam_'+side+str(h),[(sign*.098+.0376*math.sin(2*math.pi*j/40),.001-.0356*math.cos(2*math.pi*j/40),h) for j in range(41)],.0005,'navy_light',calf)
        hippts=[(sign*.039,-.087,.835),(sign*.073,-.082,.816),(sign*.111,-.068,.794),(sign*.140,-.044,.777)]
        detail('Hip_PocketWelt_'+side,hippts,.002,'navy_dark','weighted_leg')
        detail('Hip_PocketStitch_'+side,[(x,y-.001,z-.004) for x,y,z in hippts],.00065,'navy_light','weighted_leg')
        # Long tonal side seam bends with the actual garment.
        sidepts=[]
        for z,rx,ry,cy in profiles[2:-2]:
            cx=.086+(.098-.086)*max(0,min(1,(.84-z)/.70))
            sidepts.append((sign*(cx+rx+.001),cy,z))
        ob=tube('Kai_Outside_TrouserSeam_'+side,sidepts,.0008,mats['navy_light'],sides=6)
        add(ob,weights=leg_weights(ob))
        # Bellows cargo pocket: a curved side panel and raised flap, not a box.
        def cargo_point(y,z,offset=.004):
            ry=.077 if z>.68 else .070
            rx=.080 if z>.68 else .076
            return (sign*(.089+rx*math.sqrt(max(.1,1-((y+.004)/ry)**2))+offset),y,z)
        pocket=[cargo_point(y,z) for y,z in [(-.022,.727),(-.056,.713),(-.063,.613),(-.044,.594),(.025,.601),(.032,.704)]]
        panel('CargoPocket_'+side,pocket,'navy_dark',thigh,.003,.002)
        panel('CargoPocket_Flap_'+side,[cargo_point(y,z,.006) for y,z in [(-.023,.730),(-.058,.713),(-.059,.688),(-.034,.678),(.032,.688),(.034,.713)]],'navy_light',thigh,.002,.0015)
        detail('CargoPocket_Stitch_'+side,[cargo_point(y,z,.006) for y,z in [(-.061,.679),(-.067,.618),(-.046,.603)]],.0007,'stitch',thigh)
        # Front-facing utility strap at outer thigh, with white reflective center.
        ctr=[(sign*.113,-.063,.842),(sign*.130,-.072,.801),(sign*.145,-.075,.759),(sign*.158,-.080,.713),(sign*.172,-.079,.653),(sign*.177,-.076,.605)]
        add(ribbon('Kai_HangingUtilityWebbing_'+side,ctr,.020,mats['navy_dark'],thickness=.003),rigid='weighted_leg')
        if side=='l':
            add(ribbon('Kai_ReflectiveTab_'+side,[(sign*.161,-.083,.753),(sign*.165,-.086,.710),(sign*.175,-.084,.651),(sign*.179,-.081,.614)],.013,mats['white'],thickness=.001),rigid=thigh)
        else:
            add(ribbon('Kai_CyanTab_'+side,[(sign*.131,-.075,.799),(sign*.139,-.078,.777),(sign*.145,-.078,.760)],.011,mats['cyan'],thickness=.001),rigid='weighted_leg')
        # Small triangular cyan woven patch on cargo flap, laid on its outward surface.
        panel('Cargo_Emblem_'+side,[cargo_point(y,z,.009) for y,z in [(-.055,.704),(-.047,.704),(-.051,.697)]],'cyan',thigh,.0005,0)

    # TRAINERS. Longitudinal shoe lasts and a multi-layer sculpted sole.
    for sign,side in [(1,'l'),(-1,'r')]:
        foot='foot_'+side; cx=sign*.098
        def xyz(x,y,z): return (cx+sign*x,y,z)
        def shoe_mesh(name,vv,ff,mat):
            if sign<0: ff=[f[::-1] for f in ff]
            return add(mesh_object('Kai_'+name+'_'+side,[xyz(*v) for v in vv],ff,mats[mat]),rigid=foot,unwrap=True)

        # Footprint loops preserve a recognisable narrow athletic last.
        def sole_outline(a,scale=1):
            co=math.cos(a); si=math.sin(a)
            width=.049*(.82+.18*(co+1)/2)
            width*=1-.035*math.exp(-((co-.10)/.30)**2)
            return (scale*width*si,-.054-scale*.126*co)
        sole_n=64
        layers=[(.008,.985),(.012,1.012),(.021,1.02),(.027,1.016),(.042,.999),(.049,.973)]
        vv=[];ff=[]
        for h,sc in layers:
            for j in range(sole_n):
                a=2*math.pi*j/sole_n; x,y=sole_outline(a,sc)
                lift=.011*max(0,math.cos(a))**5
                vv.append((x,y,h+lift))
        ff.append(tuple(range(sole_n-1,-1,-1)))
        for k in range(len(layers)-1):
            for j in range(sole_n):
                a=k*sole_n+j;b=k*sole_n+(j+1)%sole_n
                ff.append((a,b,b+sole_n,a+sole_n))
        ff.append(tuple((len(layers)-1)*sole_n+j for j in range(sole_n)))
        sole=shoe_mesh('Trainer_SculptedSole',vv,ff,'white')
        sole.data.materials.append(mats['rubber']);sole.data.materials.append(mats['navy_light'])
        for p in sole.data.polygons:
            if p.index<1+sole_n*2:p.material_index=1
            elif 1+sole_n*2<=p.index<1+sole_n*3:p.material_index=2
        bevel=sole.modifiers.new('Sole molded bevel','BEVEL');bevel.width=.0015;bevel.segments=2

        sections=[(-.180,.003,.052,.066),(-.176,.026,.048,.078),(-.164,.041,.044,.088),(-.146,.046,.043,.096),(-.123,.047,.042,.105),(-.098,.046,.043,.114),(-.073,.044,.044,.126),(-.049,.043,.045,.142),(-.025,.044,.046,.151),(.002,.045,.047,.151),(.026,.043,.047,.145),(.047,.037,.045,.135),(.063,.020,.043,.117),(.067,.003,.045,.097)]
        vv=[];ff=[];sn=24
        for y,rx,bottom,top in sections:
            for j in range(sn):
                a=2*math.pi*j/sn
                # Superelliptical arch is soft over the toe and stands upright at the heel.
                co=math.cos(a); si=math.sin(a)
                x=rx*math.copysign(abs(co)**.83,co)
                z=(top+bottom)/2+(top-bottom)/2*math.copysign(abs(si)**.77,si)
                vv.append((x,y,z))
        for k in range(len(sections)-1):
            for j in range(sn):
                a=k*sn+j;b=k*sn+(j+1)%sn;ff.append((a,b,b+sn,a+sn))
        ff.extend([tuple(range(sn-1,-1,-1)),tuple((len(sections)-1)*sn+j for j in range(sn))])
        upper=shoe_mesh('Trainer_UpperLast',vv,[f[::-1] for f in ff],'white');sub(upper,1)

        # Padded, open ankle collar: custom four concentric height contours.
        vv=[];ff=[];cn=48
        for rx,ry,z in [(.045,.043,.131),(.046,.044,.147),(.038,.036,.155),(.033,.030,.146),(.033,.030,.134)]:
            for j in range(cn):
                a=2*math.pi*j/cn;vv.append((rx*math.sin(a),.010-ry*math.cos(a),z+.004*math.cos(a)))
        for k in range(4):
            for j in range(cn):
                a=k*cn+j;b=k*cn+(j+1)%cn;ff.append((a,b,b+cn,a+cn))
        collar=shoe_mesh('Trainer_PaddedCollar',vv,ff,'navy_dark');sub(collar,1)
        collar.data.materials.append(mats['cyan_light'])
        for p in collar.data.polygons:
            if cn<=p.index<cn*2:p.material_index=1

        # Tongue is shaped along the instep with a softly rounded crown.
        vv=[];ff=[]
        tongue_sections=[(-.114,.108,.023),(-.104,.118,.026),(-.079,.134,.027),(-.053,.151,.029),(-.035,.161,.028),(-.027,.164,.023)]
        for y,z,w in tongue_sections:
            for j in range(7):
                u=(j-3)/3;vv.append((w*u,y,z-.006*u*u))
        for k in range(len(tongue_sections)-1):
            for j in range(6):a=k*7+j;ff.append((a,a+1,a+8,a+7))
        tongue=shoe_mesh('Trainer_QuiltedTongue',vv,ff,'navy_light');sub(tongue,1)
        mod=tongue.modifiers.new('Tongue padded thickness','SOLIDIFY');mod.thickness=.004
        panel('Trainer_TongueBadge_'+side,[xyz(-.013,-.041,.160),xyz(.013,-.041,.160),xyz(.012,-.030,.166),xyz(-.012,-.030,.166)],'cyan',foot,.001,.001)
        panel('Trainer_TongueTriangle_'+side,[xyz(-.007,-.038,.162),xyz(.007,-.038,.162),xyz(0,-.032,.166)],'white',foot,.0006,0)

        # Overlays follow the last. Outer and inner quarters have different cyan panels.
        for flank in [-1,1]:
            p=[(flank*.046,-.138,.054),(flank*.047,-.124,.079),(flank*.044,-.108,.092),(flank*.044,-.081,.082),(flank*.046,-.063,.056)]
            panel('Trainer_ToeOverlay_'+side+str(flank),[xyz(*q) for q in p],'white',foot,.002,.0015)
            p=[(flank*.046,-.103,.056),(flank*.045,-.094,.087),(flank*.044,-.078,.108),(flank*.043,-.061,.118),(flank*.044,-.051,.083),(flank*.046,-.064,.055)]
            panel('Trainer_CyanQuarter_'+side+str(flank),[xyz(*q) for q in p],'cyan',foot,.002,.0015)
            p=[(flank*.045,-.049,.055),(flank*.044,-.039,.083),(flank*.043,-.023,.113),(flank*.044,-.005,.127),(flank*.045,.021,.103),(flank*.043,.036,.056)]
            panel('Trainer_HeelQuarter_'+side+str(flank),[xyz(*q) for q in p],'navy_light',foot,.0025,.0015)
            detail('Trainer_QuarterPiping_'+side+str(flank),[xyz(flank*.047,-.039,.061),xyz(flank*.046,-.028,.081),xyz(flank*.046,-.010,.105),xyz(flank*.044,.016,.112),xyz(flank*.042,.043,.083)],.0015,'white',foot)
            # Bottom sidewall angular shock insert, small enough to preserve sneaker scale.
            panel('Trainer_SoleInsert_'+side+str(flank),[xyz(flank*.049,-.055,.025),xyz(flank*.049,-.040,.037),xyz(flank*.045,-.017,.038),xyz(flank*.045,.004,.025),xyz(flank*.047,-.019,.023)],'cyan',foot,.001,0)
        # Toe seam horseshoe and decorative micro stitching.
        toe_line=[xyz(-.041,-.126,.075),xyz(-.036,-.143,.083),xyz(-.022,-.156,.091),xyz(0,-.160,.094),xyz(.022,-.156,.091),xyz(.036,-.143,.083),xyz(.041,-.126,.075)]
        detail('Trainer_ToeStitch_'+side,toe_line,.00065,'navy_light',foot)
        # Lace bars and crossed runs on the tongue, each arc stands above the surface.
        lace_rows=[(-.104,.119,.021),(-.086,.132,.023),(-.068,.146,.025),(-.050,.158,.024)]
        for r,(y,z,w) in enumerate(lace_rows):
            for flank in [-1,1]:
                pts=[]
                for j in range(13):
                    a=2*math.pi*j/12;pts.append(xyz(flank*(w+.003)+.0027*math.cos(a),y+.0017*math.sin(a),z-.004+.0016*math.sin(a)))
                detail('Trainer_Eyelet_'+side+str(r)+str(flank),pts,.0007,'silver',foot,sides=6)
            if r<len(lace_rows)-1:
                y2,z2,w2=lace_rows[r+1]
                for flank in [-1,1]:
                    pts=[xyz(flank*w,y,z),xyz(flank*w*.4,y+(y2-y)*.32,z+(z2-z)*.32+.005),xyz(-flank*w2*.4,y+(y2-y)*.7,z+(z2-z)*.7+.005),xyz(-flank*w2,y2,z2)]
                    detail('Trainer_Lace_'+side+str(r)+str(flank),pts,.00125,'white',foot)
        detail('Trainer_LaceKnot_'+side,[xyz(-.010,-.046,.164),xyz(0,-.044,.167),xyz(.010,-.046,.164)],.0015,'white',foot)
        for flank in [-1,1]:
            detail('Trainer_LaceLoop_'+side+str(flank),[xyz(0,-.044,.167),xyz(flank*.014,-.032,.166),xyz(flank*.021,-.038,.162),xyz(flank*.009,-.047,.166),xyz(0,-.044,.167)],.0011,'white',foot)
        # Functional heel pull loop, curved over heel.
        add(ribbon('Kai_Trainer_HeelPull_'+side,[xyz(-.009,.051,.122),xyz(-.008,.063,.156),xyz(-.007,.051,.166),xyz(-.008,.042,.150)],.013,mats['cyan'],width_axis=(sign,0,0),thickness=.002),rigid=foot)
        # Tread bands under the outsole, eight sculpted chevrons per shoe.
        for j in range(8):
            yy=-.146+j*.025
            ww=.034 if j<6 else .028
            points=[xyz(-ww,yy-.003,.006),xyz(-ww*.55,yy+.003,.006),xyz(0,yy-.001,.005),xyz(ww*.55,yy+.003,.006),xyz(ww,yy-.003,.006)]
            detail('Trainer_Tread_'+side+str(j),points,.003,'rubber',foot,sides=6)

    # Compact hip pouch. Rounded rectangular cross sections are authored in the XZ plane.
    pouch_center=Vector((.155,-.125,.806))
    vv=[];ff=[];pn=40
    for depth,scale in [(.017,.91),(.014,1),(-.014,1),(-.018,.91)]:
        for j in range(pn):
            a=2*math.pi*j/pn;co=math.cos(a);si=math.sin(a)
            x=.037*math.copysign(abs(co)**.37,co)*scale
            z=.044*math.copysign(abs(si)**.35,si)*scale
            vv.append(tuple(pouch_center+Vector((x,depth,z))))
    for k in range(3):
        for j in range(pn):
            a=k*pn+j;b=k*pn+(j+1)%pn;ff.append((a,b,b+pn,a+pn))
    ff.extend([tuple(range(pn-1,-1,-1)),tuple(3*pn+j for j in range(pn))])
    pouch=mesh_object('Kai_UtilityPouch',vv,ff,mats['navy_dark']);add(pouch,rigid='pelvis',unwrap=True)
    mod=pouch.modifiers.new('Soft bag corners','BEVEL');mod.width=.002;mod.segments=3
    outline=[]
    for j in range(pn+1):
        a=2*math.pi*j/pn;co=math.cos(a);si=math.sin(a)
        outline.append((.155+.036*math.copysign(abs(co)**.37,co),-.144,.806+.043*math.copysign(abs(si)**.35,si)))
    detail('Pouch_ReflectivePiping',outline,.0013,'navy_light','pelvis')
    panel('Pouch_FrontPocket',[(.128,-.146,.799),(.182,-.146,.799),(.183,-.146,.774),(.179,-.146,.768),(.132,-.146,.768),(.127,-.146,.774)],'navy','pelvis',.0015,.002)
    detail('Pouch_ZipTrack',[(.129,-.146,.829),(.154,-.146,.830),(.181,-.146,.829)],.0019,'black','pelvis')
    detail('Pouch_ZipTape',[(.129,-.149,.831),(.154,-.149,.832),(.181,-.149,.831)],.0007,'cyan','pelvis')
    for j in range(15):
        xx=.13+j*.0035
        detail('Pouch_ZipTooth_'+str(j),[(xx,-.148,.8287),(xx,-.148,.831)],.00045,'silver','pelvis',sides=4)
    detail('Pouch_ZipPull',[(.137,-.150,.83),(.137,-.153,.821),(.139,-.152,.817),(.142,-.151,.822),(.139,-.150,.829)],.0011,'silver','pelvis')
    add(ribbon('Kai_Pouch_CyanZipTab',[(.139,-.155,.820),(.138,-.156,.809),(.138,-.156,.802)],.006,mats['cyan'],thickness=.0014),rigid='pelvis')
    panel('Pouch_TrianglePatch',[(.143,-.150,.794),(.168,-.150,.794),(.1555,-.150,.777)],'white','pelvis',.0008,0)
    panel('Pouch_TriangleInset',[(.148,-.151,.791),(.163,-.151,.791),(.1555,-.151,.781)],'navy_light','pelvis',.0005,0)

    # Cross-body webbing drapes over the outside of the jacket.
    front=[(-.134,-.059,1.208),(-.126,-.069,1.19),(-.103,-.078,1.158),(-.069,-.090,1.113),(-.028,-.094,1.06),(.015,-.094,1.009),(.061,-.087,.958),(.108,-.095,.9),(.149,-.113,.85)]
    back=[(-.134,-.059,1.208),(-.141,-.006,1.219),(-.132,.061,1.199),(-.107,.095,1.16),(-.060,.107,1.101),(-.008,.108,1.039),(.045,.106,.977),(.095,.096,.920),(.143,.060,.868),(.161,.001,.85),(.149,-.113,.85)]
    def torso_weights(ob):
        weights={}
        levels=[(.84,'pelvis'),(.94,'spine_01'),(1.065,'spine_02'),(1.185,'spine_03')]
        for v in ob.data.vertices:
            z=v.co.z
            if z<=levels[0][0]:pairs=[(levels[0][1],1)]
            elif z>=levels[-1][0]:pairs=[(levels[-1][1],1)]
            else:
                for k in range(len(levels)-1):
                    if levels[k][0]<=z<=levels[k+1][0]:
                        t=(z-levels[k][0])/(levels[k+1][0]-levels[k][0]);pairs=[(levels[k][1],1-t),(levels[k+1][1],t)];break
            for bone,w in pairs:
                if w:weights.setdefault(bone,{})[v.index]=w
        return weights
    for name,centers in [('Front',front),('Back',back)]:
        ob=ribbon('Kai_Crossbody_Webbing_'+name,centers,.023,mats['black'],width_axis=(.80,0,.60),thickness=.0035)
        sub(ob,1);add(ob,weights=torso_weights(ob))
        for sign in [-1,1]:
            points=[(x+sign*.0075,y+(-.002 if name=='Front' else .002),z+sign*.0056) for x,y,z in centers]
            ob=tube('Kai_Webbing_Stitch_'+name+str(sign),points,.00055,mats['navy_light'],sides=6)
            add(ob,weights=torso_weights(ob))
    # A real rectangular strap slider and keeper near the sternum.
    for name,cz,cx in [('Slider',1.065,-.031),('Keeper',.96,.060)]:
        center=Vector((cx,-.098 if name=='Slider' else -.091,cz)); u=Vector((.8,0,.6)); v=Vector((-.6,0,.8))
        pts=[center+u*x+v*z for x,z in [(-.014,-.014),(.014,-.014),(.014,.014),(-.014,.014),(-.014,-.014)]]
        ob=tube('Kai_Webbing_'+name,[tuple(p) for p in pts],.0016,mats['silver' if name=='Slider' else 'navy_light'],sides=8)
        add(ob,weights=torso_weights(ob))
        ob=tube('Kai_Webbing_'+name+'_Bar',[tuple(center-u*.014),tuple(center+u*.014)],.0013,mats['silver' if name=='Slider' else 'navy_light'],sides=8)
        add(ob,weights=torso_weights(ob))
    return objects
