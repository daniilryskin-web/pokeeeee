"""Render real Blender scene inspection images (never concept art)."""
import bpy,sys,os,math,json
from mathutils import Vector
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
if not bpy.data.objects.get('RIG_Kai'):bpy.ops.wm.open_mainfile(filepath=os.path.join(ROOT,'Kai_Character.blend'))
scene=bpy.context.scene;rig=bpy.data.objects['RIG_Kai'];cam=scene.camera
if '--workbench' in args:
 scene.render.engine='BLENDER_WORKBENCH'
 scene.display.shading.light='STUDIO';scene.display.shading.studio_light='paint.sl'
 scene.display.shading.color_type='MATERIAL';scene.display.shading.show_shadows=True
 scene.display.shading.show_cavity=True;scene.display.shading.cavity_type='BOTH'
 scene.display.shading.curvature_ridge_factor=1.2;scene.display.shading.curvature_valley_factor=1.1
 scene.display.shading.show_specular_highlight=True
 scene.display.shading.background_type='WORLD';scene.world.color=(.065,.08,.105)
else:
 scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=False
scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG'
def view(name,loc,target,scale,action='Idle',frame=1,size=(720,900)):
 rig.animation_data.action=bpy.data.actions.get('AN_Kai_'+action);scene.frame_set(frame)
 cam.location=loc;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=scale
 scene.render.resolution_x=size[0];scene.render.resolution_y=size[1];scene.render.filepath=os.path.join(ROOT,'previews',name+'.png')
 bpy.ops.render.render(write_still=True)
 print('RENDERED',name,flush=True)
if '--animation' in args:
 scene.render.resolution_x=480;scene.render.resolution_y=640;scene.render.resolution_percentage=100
 if '--preview-fast' in args:
  scene.render.resolution_x=384;scene.render.resolution_y=480;scene.frame_step=2;scene.render.fps=15
 cam.location=(2.6,-5,2.1);cam.rotation_euler=(Vector((0,0,.80))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=1.9
 scene.render.image_settings.file_format='FFMPEG';scene.render.ffmpeg.format='MPEG4';scene.render.ffmpeg.codec='H264';scene.render.ffmpeg.constant_rate_factor='MEDIUM'
 for name in ['Idle','Walk','Run','Sprint','Jump','Fall','Land','Crouch','Turn','Interact','Throw']:
  action=bpy.data.actions['AN_Kai_'+name];rig.animation_data.action=action
  scene.frame_start=int(action.frame_range[0]);scene.frame_end=int(action.frame_range[1]);scene.render.filepath=os.path.join(ROOT,'previews','AN_Kai_'+name+'.mp4')
  bpy.ops.render.render(animation=True)
else:
 view('Kai_ThreeQuarter',(2.4,-5,2.0),(0,0,.82),1.83)
 if '--hero-only' not in args:
  view('Kai_Front',(0,-5,1.00),(0,0,.82),1.85)
  view('Kai_Back',(-1.7,5,1.9),(0,0,.82),1.84)
  view('Kai_Side',(5,0,1.40),(0,0,.82),1.84)
  view('Kai_Face',(.45,-3,1.65),(0,-.015,1.44),.405,size=(850,850))
  view('QA_Run',(2.8,-5,1.8),(0,0,.80),1.95,'Run',7,size=(550,700))
  view('QA_Crouch',(2.8,-5,1.8),(0,0,.65),1.65,'Crouch',1,size=(550,700))
  view('QA_Throw',(2.8,-5,1.8),(0,0,.90),2.0,'Throw',23,size=(550,700))
