"""Small portable PBR texture library: sRGB base color, linear scalar/normal maps."""
import bpy, os, math
import numpy as np
PALETTE={
 'skin':((.95,.78,.69),.5,0,'skin'),
 'skin_shadow':((.67,.36,.30),.59,0,'skin'),
 'hair':((.91,.92,.96),.34,0,'hair'),
 'hair_shadow':((.60,.64,.73),.44,0,'hair'),
 'eye_white':((.95,.97,1.0),.22,0,'smooth'),
 'iris':((.035,.48,.84),.25,0,'smooth'),
 'pupil':((.008,.025,.08),.3,0,'smooth'),
 'navy':((.093,.113,.175),.77,0,'fabric'),
 'navy_light':((.15,.19,.28),.73,0,'fabric'),
 'navy_dark':((.045,.055,.095),.8,0,'fabric'),
 'cyan':((.035,.61,.88),.52,0,'fabric'),
 'cyan_light':((.35,.79,.96),.57,0,'fabric'),
 'white':((.88,.90,.93),.65,0,'fabric'),
 'rubber':((.105,.13,.17),.83,0,'rubber'),
 'silver':((.59,.67,.74),.28,.85,'metal'),
 'black':((.025,.031,.046),.65,0,'fabric'),
 'stitch':((.32,.40,.52),.8,0,'fabric')}

def srgb_to_lin(c):
 return c/12.92 if c<.04045 else ((c+.055)/1.055)**2.4

def save_image(name,arr,path,colorspace):
 h,w,ch=arr.shape
 img=bpy.data.images.new(name,width=w,height=h,alpha=True)
 img.colorspace_settings.name=colorspace
 img.pixels.foreach_set(arr.astype(np.float32).ravel())
 img.filepath_raw=path;img.file_format='PNG';img.save()
 return img

def build_materials(directory):
 os.makedirs(directory,exist_ok=True); mats={}; n=512
 yy,xx=np.mgrid[:n,:n].astype(np.float32); rng=np.random.default_rng(27)
 for name,(color,rough,metal,kind) in PALETTE.items():
  noise=rng.normal(0,1,(n,n)).astype(np.float32)
  if kind=='fabric':
   weave=np.sin(xx*math.pi/2)*np.cos(yy*math.pi/2)
   detail=.025*weave+.008*noise
   hx=.025*np.cos(xx*math.pi/2)*np.cos(yy*math.pi/2); hy=-.025*np.sin(xx*math.pi/2)*np.sin(yy*math.pi/2)
  elif kind=='hair':
   detail=.012*np.sin(xx*.2)+.002*noise;hx=.018*np.cos(xx*.2);hy=np.zeros_like(xx)
  else:
   detail=.005*noise; hx=.005*np.sin(xx*.5);hy=.005*np.cos(yy*.5)
  base=np.ones((n,n,4),dtype=np.float32)
  for c in range(3):base[:,:,c]=np.clip(color[c]*(1+detail),0,1)
  # Image datablock pixel storage follows the declared sRGB space. Keep these
  # values encoded: pre-linearizing here would darken PNGs a second time.
  roughmap=np.ones_like(base);roughmap[:,:,:3]=np.clip(rough+detail*.4,0,1)[:,:,None]
  metalmap=np.ones_like(base);metalmap[:,:,:3]=metal
  normal=np.ones_like(base);normal[:,:,0]=.5+hx;normal[:,:,1]=.5+hy;normal[:,:,2]=np.sqrt(np.maximum(0,1-hx*hx-hy*hy))*.5+.5
  paths={};images={}
  for suffix,arr,cs in [('BaseColor',base,'sRGB'),('Roughness',roughmap,'Non-Color'),('Metallic',metalmap,'Non-Color'),('Normal',normal,'Non-Color')]:
   path=os.path.join(directory,f'T_Kai_{name}_{suffix}.png')
   images[suffix]=save_image(f'T_Kai_{name}_{suffix}',arr,path,cs)
  mat=bpy.data.materials.new('M_Kai_'+name);mat.use_nodes=True
  mat.diffuse_color=tuple(srgb_to_lin(c) for c in color)+(1,)
  mat.roughness=rough;mat.metallic=metal
  nodes=mat.node_tree.nodes;links=mat.node_tree.links;bsdf=nodes.get('Principled BSDF')
  for i,suffix in enumerate(['BaseColor','Roughness','Metallic','Normal']):
   tex=nodes.new('ShaderNodeTexImage');tex.image=images[suffix];tex.label=suffix;tex.location=(-650,250-i*250)
   if suffix=='Normal':
    nm=nodes.new('ShaderNodeNormalMap');nm.location=(-260,-250);nm.inputs['Strength'].default_value=.3 if kind=='fabric' else .12
    links.new(tex.outputs['Color'],nm.inputs['Color']);links.new(nm.outputs['Normal'],bsdf.inputs['Normal'])
   else:links.new(tex.outputs['Color'],bsdf.inputs[{'BaseColor':'Base Color','Roughness':'Roughness','Metallic':'Metallic'}[suffix]])
  if kind=='skin':bsdf.inputs['Subsurface Weight'].default_value=.065;bsdf.inputs['Subsurface Radius'].default_value=(1,.4,.25)
  if kind=='hair' and 'Anisotropic' in bsdf.inputs:bsdf.inputs['Anisotropic'].default_value=.18
  if name in ('pupil','eye_white','iris'):bsdf.inputs['Coat Weight'].default_value=.2
  mat['texture_note']='Tileable procedural PBR; no high-poly sculpt bake. OpenGL tangent normal.'
  mats[name]=mat
 return mats
