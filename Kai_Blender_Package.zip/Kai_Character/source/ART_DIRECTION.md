# Kai: procedural 3D development asset

Reference: user supplied anime teenage boy turnaround. Artistic target is high, but this is an authored procedural candidate requiring artist review, NOT a certified production-final or faithful sculpt.

Coordinates: metres; Z up; FRONT is negative Y; character left is positive X. A pose. Ground Z=0. Height with hair about 1.62 m. Rest neutral expression.

Landmarks (mirror X for right):
- pelvis z .84, x 0, y 0; spine_01 z .91, spine_02 1.045, spine_03 1.18
- neck_01 (0,0,1.235), head (0,0,1.31)
- clavicle_l (.035,0,1.185) to upperarm_l (.18,0,1.20)
- upperarm_l (.18,0,1.20) to lowerarm_l (.315,0,1.025)
- lowerarm_l (.315,0,1.025) to hand_l (.425,-.008,.88)
- hand_l (.425,-.008,.88) to (.475,-.008,.815)
- thigh_l (.086,0,.84) to calf_l (.092,-.018,.46)
- calf_l (.092,-.018,.46) to foot_l (.098,0,.105)
- foot_l (.098,0,.105) to ball_l (.098,-.115,.045)
- ball_l (.098,-.115,.045) to (.098,-.19,.045)

Head: chin z1.285; crown1.535; eye line z1.422; width ~.205; face front y -.094 at eyes. Eye separation ~.088. Nose protrudes to y-.125. Subtle anime nose and smile, no giant spherical eyes. Head neck should connect gracefully. Hair snow-white, layered swept chunky anime locks, asymmetrical fringe, silhouette to z1.62. Neck tube to z1.205.

Clothes: unzipped dark navy hooded jacket. White inner shirt, cyan hood lining, white diagonal sleeve bands; wrist cuffs at z~.943 and upper y0. Puffy but restrained folds. Navy cargo trousers waist .86 to ankle .125; waist width .29. Detailed grey/white/navy/cyan trainers floor0 to ankle .17. Black fingerless gloves (root builds skin hands/gloves). Crossbody strap on back and front, pouch at character LEFT hip (.155,-.095,.825), no huge blocks. Cyan strap tabs, triangle emblems, zipper pulls, piping, seams, shoelaces, pockets.

Materials via ctx['mats']: skin, skin_shadow, hair, hair_shadow, eye_white, iris, pupil, navy, navy_light, navy_dark, cyan, cyan_light, white, rubber, silver, black, stitch. All PBR with Principled and generated/baked texture inputs. Do not overwrite material definitions; may add nuanced materials if needed.

Python modules import from kai_common. Module entry build(ctx) returns list of created mesh objects. ctx has mats and register. Register signature ctx['register'](object, weights=None, rigid=None); weights can be dict bone_name -> dict {vertex_index: weight}; rigid string for rigid attachment. Every visual mesh must register. Mesh topology should be custom authored surfaces/quads, not stock primitive assembly. Helper mesh_object(name,verts,faces,material) sets smooth and UV placeholder; implement analytic UV or unwrap. uv_smart(obj) final unwrap supported. tube(name, points, radii, material, sides=12, aspect=1.0, caps=True) is detail geometry helper, not main anatomical modeling. stitch/detail tubes rigid or weighted. No lights/cameras in component files.

Rig names: root,pelvis,spine_01,spine_02,spine_03,neck_01,head,clavicle_l/r,upperarm_l/r,lowerarm_l/r,hand_l/r,thigh_l/r,calf_l/r,foot_l/r,ball_l/r. Fingers will be added by main integrator. Attach head/hair rigid head; neck can weight neck_01/head. Clothing weights may be supplied or left None for main integrator to assign. Name meshes with Kai_ prefix. Each module independently syntax compilable. Avoid changing other agents' files. Use Blender 4.3 API.
