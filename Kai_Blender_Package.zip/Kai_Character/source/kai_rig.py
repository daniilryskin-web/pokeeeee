import bpy,math
from mathutils import Vector

def hand_layout(sign):
 origin=Vector((sign*.425,-.008,.88));d=Vector((sign*.605,0,-.796));w=Vector((sign*.796,0,.605))
 layout={}
 for name,offset,length in [('index',-.017,.050),('middle',-.005,.056),('ring',.008,.051),('pinky',.020,.040)]:
  start=origin+d*.046+w*offset
  direction=(d+w*(offset*3)).normalized()
  # Subtle relaxed curl, with joints tucked towards the palm front.
  points=[start,start+direction*length*.38+Vector((0,-.001,0)),start+direction*length*.71+Vector((0,-.004,0)),start+direction*length+Vector((0,-.006,0))]
  layout[name]=points
 start=origin+d*.018-w*.019
 direction=(d*.7-w*.75).normalized()
 layout['thumb']=[start,start+direction*.018,start+direction*.032+Vector((0,-.002,0)),start+direction*.044+Vector((0,-.004,0))]
 return origin,d,w,layout

def build_rig():
 arm=bpy.data.armatures.new('SKEL_Kai');rig=bpy.data.objects.new('RIG_Kai',arm);bpy.context.collection.objects.link(rig)
 bpy.context.view_layer.objects.active=rig;rig.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
 def bone(name,head,tail,parent=None):
  b=arm.edit_bones.new(name);b.head=head;b.tail=tail;b.roll=0
  if parent:b.parent=arm.edit_bones[parent]
  b.use_deform=True;return b
 bone('root',(0,0,0),(0,0,.12))
 bone('pelvis',(0,0,.84),(0,0,.91),'root')
 bone('spine_01',(0,0,.91),(0,0,1.045),'pelvis')
 bone('spine_02',(0,0,1.045),(0,0,1.18),'spine_01')
 bone('spine_03',(0,0,1.18),(0,0,1.235),'spine_02')
 bone('neck_01',(0,0,1.235),(0,0,1.31),'spine_03')
 bone('head',(0,0,1.31),(0,0,1.515),'neck_01')
 for sign,suffix in [(1,'l'),(-1,'r')]:
  bone('clavicle_'+suffix,(sign*.035,0,1.185),(sign*.18,0,1.20),'spine_03')
  bone('upperarm_'+suffix,(sign*.18,0,1.20),(sign*.315,0,1.025),'clavicle_'+suffix)
  bone('lowerarm_'+suffix,(sign*.315,0,1.025),(sign*.425,-.008,.88),'upperarm_'+suffix)
  bone('hand_'+suffix,(sign*.425,-.008,.88),(sign*.475,-.008,.815),'lowerarm_'+suffix)
  bone('thigh_'+suffix,(sign*.086,0,.84),(sign*.092,-.018,.46),'pelvis')
  bone('calf_'+suffix,(sign*.092,-.018,.46),(sign*.098,0,.105),'thigh_'+suffix)
  bone('foot_'+suffix,(sign*.098,0,.105),(sign*.098,-.115,.045),'calf_'+suffix)
  bone('ball_'+suffix,(sign*.098,-.115,.045),(sign*.098,-.19,.045),'foot_'+suffix)
  _,_,_,layout=hand_layout(sign)
  for name,ps in layout.items():
   for i in range(3):bone(f'{name}_{i+1:02d}_{suffix}',ps[i],ps[i+1],f'{name}_{i:02d}_{suffix}' if i else 'hand_'+suffix)
 bpy.ops.object.mode_set(mode='OBJECT');rig.show_in_front=True;arm.display_type='OCTAHEDRAL'
 rig['asset_status']='Procedural development candidate; artist review required.'
 rig['forward_axis']='-Y';rig['height_units']='metres';rig['animation_note']='Authored procedural in-place motions, not motion capture.'
 return rig
